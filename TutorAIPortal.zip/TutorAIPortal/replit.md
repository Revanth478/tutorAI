# Overview

This is a full-stack learning platform called "Tutor AI" that provides interactive programming tutorials and quizzes for Python, Java, and AI/Machine Learning. The application features user authentication, progress tracking, quiz functionality, and an AI-powered chatbot for learning assistance.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built with **React 18** and **TypeScript**, using modern React patterns:
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: Zustand for authentication state with localStorage persistence
- **Data Fetching**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS
- **Styling**: Tailwind CSS with CSS custom properties for theming

The frontend follows a component-based architecture with clear separation of concerns:
- Pages for route components
- Reusable UI components from Shadcn/ui
- Custom hooks for mobile detection and toast notifications
- Centralized API client with authentication handling

### Backend Architecture
The server uses **Express.js** with **TypeScript** in ES module format:
- **API Design**: RESTful endpoints with proper HTTP methods and status codes
- **Authentication**: JWT-based authentication with bcrypt for password hashing
- **Middleware**: Request logging, JSON parsing, and authentication middleware
- **Database Layer**: Abstracted storage interface supporting both in-memory and database implementations
- **Error Handling**: Centralized error handling middleware

### Data Storage
**Database**: PostgreSQL using Drizzle ORM with Neon serverless hosting:
- **Schema**: Well-defined tables for users, tutorials, quiz questions, attempts, progress tracking, and chat sessions
- **Migrations**: Drizzle Kit for schema management and migrations
- **Connection**: Neon serverless with WebSocket support for edge compatibility

**Data Models**:
- Users with authentication credentials
- Tutorials organized by programming language
- Quiz questions with multiple choice answers
- User progress tracking per tutorial
- Quiz attempt history with scoring
- Chat sessions for AI conversations

### Authentication & Authorization
- **JWT Tokens**: Secure token-based authentication
- **Password Security**: Bcrypt hashing with proper salt rounds
- **Protected Routes**: Middleware-based route protection
- **Client Storage**: Persistent authentication state in localStorage
- **Automatic Headers**: Authentication headers automatically added to API requests

### Development & Build System
**Build Tools**:
- **Vite**: Fast development server and build tool for the frontend
- **ESBuild**: Fast TypeScript compilation for the backend
- **TypeScript**: Full type safety across frontend, backend, and shared types

**Development Features**:
- Hot module replacement in development
- Shared type definitions between client and server
- Path aliases for clean imports
- Replit-specific plugins for development environment

## External Dependencies

### Database & Hosting
- **Neon Database**: Serverless PostgreSQL hosting with edge-compatible WebSocket connections
- **Drizzle ORM**: Type-safe database operations with excellent TypeScript integration

### Authentication & Security
- **JWT (jsonwebtoken)**: Token-based authentication
- **bcrypt**: Secure password hashing
- **Zod**: Runtime type validation for API inputs

### UI & Styling
- **Radix UI**: Accessible, unstyled UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide Icons**: Consistent icon library
- **Class Variance Authority**: Type-safe component variants

### Development Tools
- **React Query**: Server state management and caching
- **Wouter**: Lightweight React router
- **Zustand**: Simple state management
- **PostCSS**: CSS processing with Tailwind

### Runtime & Utilities
- **Node.js**: Server runtime environment
- **WebSocket (ws)**: Real-time communication support
- **Nanoid**: Unique ID generation
- **dotenv**: Environment variable management

The architecture emphasizes type safety, developer experience, and scalability while maintaining simplicity in deployment and development workflows.