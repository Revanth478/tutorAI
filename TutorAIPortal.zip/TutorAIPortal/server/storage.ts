import { 
  type User, 
  type InsertUser,
  type Tutorial,
  type InsertTutorial,
  type QuizQuestion,
  type InsertQuizQuestion,
  type QuizAttempt,
  type InsertQuizAttempt,
  type UserProgress,
  type InsertUserProgress,
  type ChatSession,
  type InsertChatSession
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Tutorial methods
  getTutorialsByLanguage(language: string): Promise<Tutorial[]>;
  getTutorial(id: string): Promise<Tutorial | undefined>;
  createTutorial(tutorial: InsertTutorial): Promise<Tutorial>;

  // Quiz methods
  getQuizQuestionsByLanguage(language: string): Promise<QuizQuestion[]>;
  getQuizQuestionsByLanguageAndConcept(language: string, concept: string): Promise<QuizQuestion[]>;
  getQuizQuestion(id: string): Promise<QuizQuestion | undefined>;
  createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion>;
  
  // Quiz attempts
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getUserQuizAttempts(userId: string, language?: string): Promise<QuizAttempt[]>;

  // User progress
  getUserProgress(userId: string, language?: string): Promise<UserProgress[]>;
  updateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;

  // Chat sessions
  getChatSession(userId: string): Promise<ChatSession | undefined>;
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  updateChatSession(id: string, messages: any[]): Promise<ChatSession | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private tutorials: Map<string, Tutorial>;
  private quizQuestions: Map<string, QuizQuestion>;
  private quizAttempts: Map<string, QuizAttempt>;
  private userProgress: Map<string, UserProgress>;
  private chatSessions: Map<string, ChatSession>;

  constructor() {
    this.users = new Map();
    this.tutorials = new Map();
    this.quizQuestions = new Map();
    this.quizAttempts = new Map();
    this.userProgress = new Map();
    this.chatSessions = new Map();
    
    // Seed with initial data
    this.seedInitialData();
  }

  private seedInitialData() {
    // Comprehensive tutorial content
    const pythonTutorials: InsertTutorial[] = [
      {
        language: 'python',
        concept: 'basics',
        title: 'Getting Started with Python',
        description: 'Learn Python basics, syntax, and your first program',
        content: 'Python is a high-level programming language known for its simplicity and readability. Python uses indentation to define code blocks and has dynamic typing, meaning you don\'t need to declare variable types explicitly. This lesson covers variables, basic syntax, operators, and control flow.',
        codeExamples: [
          {
            title: 'Hello World and Variables',
            code: '# Hello World\nprint("Hello, World!")\n\n# Variables (no type declaration needed)\nname = "Alice"\nage = 25\nheight = 5.6\nis_student = True\n\n# Print with f-strings\nprint(f"Name: {name}, Age: {age}")'
          },
          {
            title: 'Basic Operations and Control Flow',
            code: '# Arithmetic operations\nx = 10\ny = 3\nprint(f"Addition: {x + y}")\nprint(f"Division: {x / y}")\nprint(f"Floor division: {x // y}")\nprint(f"Modulus: {x % y}")\n\n# Control flow\nif age >= 18:\n    print("Adult")\nelse:\n    print("Minor")\n\n# Loops\nfor i in range(5):\n    print(f"Number: {i}")'
          }
        ],
        orderIndex: 1
      },
      {
        language: 'python',
        concept: 'datatypes',
        title: 'Data Types in Python',
        description: 'Understanding strings, numbers, booleans, lists, tuples, sets, and dictionaries',
        content: 'Python has several built-in data types: strings (text), integers (whole numbers), floats (decimal numbers), booleans (True/False), lists (ordered, mutable), tuples (ordered, immutable), sets (unordered, unique elements), and dictionaries (key-value pairs). Understanding these is essential for effective programming.',
        codeExamples: [
          {
            title: 'Basic Data Types',
            code: '# Strings\nname = "Alice"\nquote = \'Learning Python is fun!\'\nmultiline = """This is a\nmultiline string"""\n\n# Numbers\nage = 25        # int\npi = 3.14159    # float\ncomplex_num = 3 + 4j  # complex\n\n# Boolean\nis_student = True\nis_teacher = False'
          },
          {
            title: 'Collections: Lists, Tuples, Sets, Dictionaries',
            code: '# List (mutable, ordered)\nfruits = ["apple", "banana", "cherry"]\nfruits.append("date")\nprint(fruits[0])  # apple\n\n# Tuple (immutable, ordered)\ncoordinates = (10, 20)\nprint(coordinates[0])  # 10\n\n# Set (unique elements)\nunique_numbers = {1, 2, 3, 2, 1}\nprint(unique_numbers)  # {1, 2, 3}\n\n# Dictionary (key-value pairs)\nstudent = {"name": "Alice", "age": 25, "grade": "A"}\nprint(student["name"])  # Alice'
          },
          {
            title: 'Type Checking and Conversion',
            code: '# Type checking\nprint(type(42))        # <class \'int\'>\nprint(type(3.14))      # <class \'float\'>\nprint(type("hello"))   # <class \'str\'>\nprint(type([1,2,3]))   # <class \'list\'>\n\n# Type conversion\nnum_str = "123"\nnum_int = int(num_str)\nnum_float = float(num_str)\nstr_from_num = str(456)\n\nprint(f"Original: {num_str}, Int: {num_int}, Float: {num_float}")'
          }
        ],
        orderIndex: 2
      },
      {
        language: 'python',
        concept: 'functions',
        title: 'Functions in Python',
        description: 'Creating reusable code blocks with parameters, return values, and advanced concepts',
        content: 'Functions are fundamental building blocks that help organize code into reusable components. They can accept parameters, perform operations, and return results. Python supports default arguments, variable-length arguments, lambda functions, and decorators.',
        codeExamples: [
          {
            title: 'Basic Functions and Parameters',
            code: '# Basic function\ndef greet(name):\n    return f"Hello, {name}!"\n\n# Function with default parameters\ndef greet_with_title(name, title="Mr/Ms"):\n    return f"Hello, {title} {name}!"\n\n# Function with multiple return values\ndef get_name_age():\n    return "Alice", 25\n\n# Usage\nprint(greet("Python"))\nprint(greet_with_title("Smith"))\nprint(greet_with_title("Johnson", "Dr"))\nname, age = get_name_age()\nprint(f"Name: {name}, Age: {age}")'
          },
          {
            title: 'Advanced Function Concepts',
            code: '# Variable-length arguments\ndef sum_all(*args):\n    return sum(args)\n\ndef print_info(**kwargs):\n    for key, value in kwargs.items():\n        print(f"{key}: {value}")\n\n# Lambda functions (anonymous)\nsquare = lambda x: x * x\nnumbers = [1, 2, 3, 4, 5]\nsquared = list(map(square, numbers))\n\n# Usage\nprint(sum_all(1, 2, 3, 4, 5))  # 15\nprint_info(name="Alice", age=25, city="New York")\nprint(f"Squared numbers: {squared}")  # [1, 4, 9, 16, 25]'
          }
        ],
        orderIndex: 3
      },
      {
        language: 'python',
        concept: 'modules',
        title: 'Modules and Packages',
        description: 'Organizing code with modules, importing, and creating packages',
        content: 'Modules allow you to organize Python code into separate files for better maintainability. You can import built-in modules, third-party packages, or create your own. Python has a rich standard library and ecosystem of packages available through pip.',
        codeExamples: [
          {
            title: 'Importing and Using Modules',
            code: '# Import entire module\nimport math\nimport datetime\nimport random\n\n# Using imported modules\nprint(f"Pi: {math.pi}")\nprint(f"Square root of 16: {math.sqrt(16)}")\nprint(f"Current time: {datetime.datetime.now()}")\nprint(f"Random number: {random.randint(1, 10)}")\n\n# Import specific functions\nfrom math import cos, sin, pi\nfrom datetime import date\n\nangle = pi / 4\nprint(f"cos(π/4) = {cos(angle):.3f}")\nprint(f"Today: {date.today()}")'
          },
          {
            title: 'Creating Your Own Module',
            code: '# File: my_utils.py\ndef calculate_area(length, width):\n    """Calculate area of rectangle."""\n    return length * width\n\ndef calculate_circle_area(radius):\n    """Calculate area of circle."""\n    import math\n    return math.pi * radius ** 2\n\nPI = 3.14159\n\n# File: main.py\n# import my_utils\n# \n# area = my_utils.calculate_area(5, 3)\n# circle_area = my_utils.calculate_circle_area(2)\n# print(f"Rectangle area: {area}")\n# print(f"Circle area: {circle_area:.2f}")\n# print(f"PI constant: {my_utils.PI}")'
          }
        ],
        orderIndex: 4
      },
      {
        language: 'python',
        concept: 'oop',
        title: 'Object-Oriented Programming',
        description: 'Classes, objects, inheritance, polymorphism, and encapsulation',
        content: 'Object-Oriented Programming (OOP) in Python allows you to create classes and objects. Key concepts include encapsulation (bundling data and methods), inheritance (creating new classes based on existing ones), and polymorphism (same interface, different implementations).',
        codeExamples: [
          {
            title: 'Classes and Objects',
            code: 'class Student:\n    def __init__(self, name, age, grade):\n        self.name = name\n        self.age = age\n        self.grade = grade\n        self.subjects = []\n    \n    def add_subject(self, subject):\n        self.subjects.append(subject)\n    \n    def get_info(self):\n        return f"{self.name}, Age: {self.age}, Grade: {self.grade}"\n    \n    def __str__(self):\n        return self.get_info()\n\n# Create objects\nstudent1 = Student("Alice", 16, "A")\nstudent2 = Student("Bob", 17, "B")\n\nstudent1.add_subject("Math")\nstudent1.add_subject("Science")\nprint(student1)\nprint(f"Subjects: {student1.subjects}")'
          },
          {
            title: 'Inheritance and Polymorphism',
            code: 'class Animal:\n    def __init__(self, name, species):\n        self.name = name\n        self.species = species\n    \n    def make_sound(self):\n        return "Some generic animal sound"\n    \n    def __str__(self):\n        return f"{self.name} the {self.species}"\n\nclass Dog(Animal):\n    def __init__(self, name, breed):\n        super().__init__(name, "Dog")\n        self.breed = breed\n    \n    def make_sound(self):\n        return "Woof!"\n    \n    def fetch(self):\n        return f"{self.name} is fetching the ball"\n\nclass Cat(Animal):\n    def __init__(self, name):\n        super().__init__(name, "Cat")\n    \n    def make_sound(self):\n        return "Meow!"\n\n# Polymorphism in action\nanimals = [Dog("Buddy", "Golden Retriever"), Cat("Whiskers")]\nfor animal in animals:\n    print(f"{animal}: {animal.make_sound()}")'
          }
        ],
        orderIndex: 5
      },
      {
        language: 'python',
        concept: 'libraries',
        title: 'Python Libraries and Frameworks',
        description: 'Popular Python libraries: NumPy, Pandas, Requests, Flask, and Django',
        content: 'Python\'s strength lies in its extensive ecosystem of libraries and frameworks. NumPy for numerical computing, Pandas for data analysis, Requests for HTTP requests, Flask for web applications, Django for full-stack development, and many more specialized libraries.',
        codeExamples: [
          {
            title: 'NumPy for Numerical Computing',
            code: 'import numpy as np\n\n# Create arrays\narr1 = np.array([1, 2, 3, 4, 5])\narr2 = np.array([[1, 2], [3, 4], [5, 6]])\n\n# Array operations\nprint(f"Array: {arr1}")\nprint(f"Mean: {np.mean(arr1)}")\nprint(f"Standard deviation: {np.std(arr1):.2f}")\nprint(f"2D Array shape: {arr2.shape}")\n\n# Mathematical operations\nresult = arr1 * 2 + 1\nprint(f"2*arr + 1: {result}")\n\n# Generate data\nlinspace_data = np.linspace(0, 10, 5)\nprint(f"Linspace: {linspace_data}")'
          },
          {
            title: 'Pandas for Data Analysis',
            code: 'import pandas as pd\nimport numpy as np\n\n# Create DataFrame\ndata = {\n    \'Name\': [\'Alice\', \'Bob\', \'Charlie\', \'Diana\'],\n    \'Age\': [25, 30, 35, 28],\n    \'City\': [\'New York\', \'London\', \'Tokyo\', \'Paris\'],\n    \'Salary\': [70000, 80000, 90000, 75000]\n}\n\ndf = pd.DataFrame(data)\nprint("DataFrame:")\nprint(df)\nprint(f"\\nAverage age: {df[\'Age\'].mean()}")\nprint(f"Max salary: ${df[\'Salary\'].max():,}")\n\n# Filter data\nhigh_earners = df[df[\'Salary\'] > 75000]\nprint("\\nHigh earners:")\nprint(high_earners[[\'Name\', \'Salary\']])'
          },
          {
            title: 'Web Development with Flask',
            code: 'from flask import Flask, jsonify, request\n\napp = Flask(__name__)\n\n# In-memory data store\nusers = [\n    {\'id\': 1, \'name\': \'Alice\', \'email\': \'alice@example.com\'},\n    {\'id\': 2, \'name\': \'Bob\', \'email\': \'bob@example.com\'}\n]\n\n@app.route(\'/\')\ndef home():\n    return "Welcome to the Python Flask API!"\n\n@app.route(\'/users\', methods=[\'GET\'])\ndef get_users():\n    return jsonify(users)\n\n@app.route(\'/users/<int:user_id>\', methods=[\'GET\'])\ndef get_user(user_id):\n    user = next((u for u in users if u[\'id\'] == user_id), None)\n    return jsonify(user) if user else (\'User not found\', 404)\n\nif __name__ == \'__main__\':\n    app.run(debug=True)'
          }
        ],
        orderIndex: 6
      }
    ];

    const javaTutorials: InsertTutorial[] = [
      {
        language: 'java',
        concept: 'basics',
        title: 'Java Fundamentals',
        description: 'Learn Java syntax, variables, data types, and basic programming concepts',
        content: 'Java is a robust, platform-independent, object-oriented programming language. Every Java program starts with a class, and the main method serves as the entry point. Java requires explicit type declarations, follows strict object-oriented principles, and compiles to bytecode that runs on the Java Virtual Machine (JVM).',
        codeExamples: [
          {
            title: 'Hello World and Basic Structure',
            code: 'public class HelloWorld {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n        \n        // This is a comment\n        /* This is a\n           multi-line comment */\n    }\n}'
          },
          {
            title: 'Variables and Data Types',
            code: 'public class DataTypes {\n    public static void main(String[] args) {\n        // Primitive types\n        int age = 25;\n        double height = 5.9;\n        float weight = 70.5f;\n        long population = 7800000000L;\n        boolean isLearning = true;\n        char grade = \'A\';\n        \n        // Reference type\n        String name = "Java Programming";\n        \n        System.out.println("Name: " + name);\n        System.out.println("Age: " + age);\n        System.out.println("Height: " + height + " feet");\n        System.out.println("Is learning: " + isLearning);\n    }\n}'
          },
          {
            title: 'Control Flow and Arrays',
            code: 'public class ControlFlow {\n    public static void main(String[] args) {\n        // Arrays\n        int[] numbers = {1, 2, 3, 4, 5};\n        String[] languages = new String[3];\n        languages[0] = "Java";\n        languages[1] = "Python";\n        languages[2] = "JavaScript";\n        \n        // For loop\n        for (int i = 0; i < numbers.length; i++) {\n            System.out.println("Number: " + numbers[i]);\n        }\n        \n        // Enhanced for loop\n        for (String lang : languages) {\n            System.out.println("Language: " + lang);\n        }\n        \n        // Conditional\n        int score = 85;\n        if (score >= 90) {\n            System.out.println("Grade A");\n        } else if (score >= 80) {\n            System.out.println("Grade B");\n        } else {\n            System.out.println("Grade C");\n        }\n    }\n}'
          }
        ],
        orderIndex: 1
      },
      {
        language: 'java',
        concept: 'oop',
        title: 'Object-Oriented Programming',
        description: 'Classes, objects, inheritance, polymorphism, encapsulation, and abstraction',
        content: 'Java\'s strength lies in OOP concepts. Key principles: Encapsulation (data hiding with private fields and public methods), Inheritance (extending classes with \'extends\'), Polymorphism (method overriding and interfaces), and Abstraction (abstract classes and interfaces). These concepts promote code reusability and maintainability.',
        codeExamples: [
          {
            title: 'Class Definition and Encapsulation',
            code: 'public class Student {\n    // Private fields (encapsulation)\n    private String name;\n    private int age;\n    private double gpa;\n    \n    // Constructor\n    public Student(String name, int age) {\n        this.name = name;\n        this.age = age;\n        this.gpa = 0.0;\n    }\n    \n    // Getter methods\n    public String getName() { return name; }\n    public int getAge() { return age; }\n    public double getGpa() { return gpa; }\n    \n    // Setter methods with validation\n    public void setGpa(double gpa) {\n        if (gpa >= 0.0 && gpa <= 4.0) {\n            this.gpa = gpa;\n        }\n    }\n    \n    // Method\n    public void study() {\n        System.out.println(name + " is studying");\n    }\n    \n    @Override\n    public String toString() {\n        return String.format("Student{name=\'%s\', age=%d, gpa=%.1f}", \n                           name, age, gpa);\n    }\n}'
          },
          {
            title: 'Inheritance and Polymorphism',
            code: '// Base class\nabstract class Animal {\n    protected String name;\n    protected int age;\n    \n    public Animal(String name, int age) {\n        this.name = name;\n        this.age = age;\n    }\n    \n    // Abstract method (must be implemented by subclasses)\n    public abstract void makeSound();\n    \n    // Concrete method\n    public void sleep() {\n        System.out.println(name + " is sleeping");\n    }\n}\n\n// Derived class\nclass Dog extends Animal {\n    private String breed;\n    \n    public Dog(String name, int age, String breed) {\n        super(name, age);\n        this.breed = breed;\n    }\n    \n    @Override\n    public void makeSound() {\n        System.out.println(name + " barks: Woof!");\n    }\n    \n    public void fetch() {\n        System.out.println(name + " is fetching the ball");\n    }\n}\n\nclass Cat extends Animal {\n    public Cat(String name, int age) {\n        super(name, age);\n    }\n    \n    @Override\n    public void makeSound() {\n        System.out.println(name + " meows: Meow!");\n    }\n}\n\n// Usage demonstrating polymorphism\npublic class AnimalTest {\n    public static void main(String[] args) {\n        Animal[] animals = {\n            new Dog("Buddy", 3, "Golden Retriever"),\n            new Cat("Whiskers", 2)\n        };\n        \n        for (Animal animal : animals) {\n            animal.makeSound(); // Polymorphism\n            animal.sleep();\n        }\n    }\n}'
          }
        ],
        orderIndex: 2
      },
      {
        language: 'java',
        concept: 'data_structures',
        title: 'Data Structures and Collections',
        description: 'Arrays, ArrayList, HashMap, Set, and other Java Collection Framework classes',
        content: 'Java provides a rich Collection Framework with interfaces like List, Set, Map and implementations like ArrayList, LinkedList, HashSet, TreeSet, HashMap, TreeMap. These data structures offer different performance characteristics and use cases for storing and manipulating data efficiently.',
        codeExamples: [
          {
            title: 'Lists and Dynamic Arrays',
            code: 'import java.util.*;\n\npublic class ListExamples {\n    public static void main(String[] args) {\n        // ArrayList - dynamic array\n        List<String> fruits = new ArrayList<>();\n        fruits.add("Apple");\n        fruits.add("Banana");\n        fruits.add("Orange");\n        \n        System.out.println("Fruits: " + fruits);\n        System.out.println("First fruit: " + fruits.get(0));\n        fruits.remove("Banana");\n        System.out.println("After removal: " + fruits);\n        \n        // LinkedList - good for frequent insertions/deletions\n        LinkedList<Integer> numbers = new LinkedList<>();\n        numbers.add(1);\n        numbers.addFirst(0);\n        numbers.addLast(2);\n        System.out.println("Numbers: " + numbers);\n        \n        // Iteration\n        for (String fruit : fruits) {\n            System.out.println("Fruit: " + fruit);\n        }\n    }\n}'
          },
          {
            title: 'Maps and Sets',
            code: 'import java.util.*;\n\npublic class MapSetExamples {\n    public static void main(String[] args) {\n        // HashMap - key-value pairs\n        Map<String, Integer> ageMap = new HashMap<>();\n        ageMap.put("Alice", 25);\n        ageMap.put("Bob", 30);\n        ageMap.put("Charlie", 28);\n        \n        System.out.println("Alice\'s age: " + ageMap.get("Alice"));\n        System.out.println("All entries:");\n        for (Map.Entry<String, Integer> entry : ageMap.entrySet()) {\n            System.out.println(entry.getKey() + ": " + entry.getValue());\n        }\n        \n        // HashSet - unique elements\n        Set<String> uniqueWords = new HashSet<>();\n        uniqueWords.add("java");\n        uniqueWords.add("python");\n        uniqueWords.add("java"); // Duplicate - won\'t be added\n        \n        System.out.println("Unique words: " + uniqueWords);\n        System.out.println("Contains \'java\': " + uniqueWords.contains("java"));\n        \n        // TreeSet - sorted unique elements\n        Set<Integer> sortedNumbers = new TreeSet<>();\n        sortedNumbers.addAll(Arrays.asList(5, 2, 8, 2, 1));\n        System.out.println("Sorted unique numbers: " + sortedNumbers);\n    }\n}'
          }
        ],
        orderIndex: 3
      },
      {
        language: 'java',
        concept: 'concurrency',
        title: 'Multithreading and Concurrency',
        description: 'Threads, synchronization, concurrent collections, and parallel processing',
        content: 'Java provides comprehensive support for multithreading and concurrent programming. Key concepts include Thread class, Runnable interface, synchronization with synchronized keyword, concurrent collections like ConcurrentHashMap, and higher-level utilities in java.util.concurrent package including ExecutorService and Future.',
        codeExamples: [
          {
            title: 'Basic Threading',
            code: '// Using Runnable interface (preferred)\nclass PrintTask implements Runnable {\n    private String message;\n    private int count;\n    \n    public PrintTask(String message, int count) {\n        this.message = message;\n        this.count = count;\n    }\n    \n    @Override\n    public void run() {\n        for (int i = 1; i <= count; i++) {\n            System.out.println(message + " - " + i);\n            try {\n                Thread.sleep(1000); // Sleep for 1 second\n            } catch (InterruptedException e) {\n                Thread.currentThread().interrupt();\n                break;\n            }\n        }\n    }\n}\n\npublic class ThreadExample {\n    public static void main(String[] args) {\n        // Create and start threads\n        Thread thread1 = new Thread(new PrintTask("Task-A", 5));\n        Thread thread2 = new Thread(new PrintTask("Task-B", 5));\n        \n        thread1.start();\n        thread2.start();\n        \n        // Wait for threads to complete\n        try {\n            thread1.join();\n            thread2.join();\n        } catch (InterruptedException e) {\n            e.printStackTrace();\n        }\n        \n        System.out.println("All tasks completed!");\n    }\n}'
          },
          {
            title: 'Synchronization and Thread Safety',
            code: 'class BankAccount {\n    private double balance;\n    private final Object lock = new Object();\n    \n    public BankAccount(double initialBalance) {\n        this.balance = initialBalance;\n    }\n    \n    // Synchronized method\n    public synchronized void deposit(double amount) {\n        balance += amount;\n        System.out.println("Deposited: $" + amount + ", Balance: $" + balance);\n    }\n    \n    // Synchronized block\n    public void withdraw(double amount) {\n        synchronized (lock) {\n            if (balance >= amount) {\n                balance -= amount;\n                System.out.println("Withdrawn: $" + amount + ", Balance: $" + balance);\n            } else {\n                System.out.println("Insufficient funds for withdrawal: $" + amount);\n            }\n        }\n    }\n    \n    public synchronized double getBalance() {\n        return balance;\n    }\n}\n\nclass BankTransaction implements Runnable {\n    private BankAccount account;\n    private String operation;\n    private double amount;\n    \n    public BankTransaction(BankAccount account, String operation, double amount) {\n        this.account = account;\n        this.operation = operation;\n        this.amount = amount;\n    }\n    \n    @Override\n    public void run() {\n        if (operation.equals("deposit")) {\n            account.deposit(amount);\n        } else {\n            account.withdraw(amount);\n        }\n    }\n}'
          },
          {
            title: 'ExecutorService and Concurrent Collections',
            code: 'import java.util.concurrent.*;\n\npublic class ConcurrencyExample {\n    public static void main(String[] args) {\n        // Thread pool with ExecutorService\n        ExecutorService executor = Executors.newFixedThreadPool(3);\n        \n        // Thread-safe collections\n        ConcurrentHashMap<String, Integer> concurrentMap = new ConcurrentHashMap<>();\n        BlockingQueue<String> queue = new ArrayBlockingQueue<>(10);\n        \n        // Submit tasks\n        for (int i = 1; i <= 5; i++) {\n            final int taskId = i;\n            executor.submit(() -> {\n                String threadName = Thread.currentThread().getName();\n                concurrentMap.put("Task-" + taskId, taskId * 10);\n                \n                try {\n                    queue.put("Result-" + taskId);\n                } catch (InterruptedException e) {\n                    Thread.currentThread().interrupt();\n                }\n                \n                System.out.println(threadName + " completed Task-" + taskId);\n            });\n        }\n        \n        // Consumer thread\n        executor.submit(() -> {\n            try {\n                while (true) {\n                    String result = queue.take(); // Blocking call\n                    System.out.println("Consumed: " + result);\n                    if (result.contains("5")) break; // Exit after last result\n                }\n            } catch (InterruptedException e) {\n                Thread.currentThread().interrupt();\n            }\n        });\n        \n        // Shutdown executor\n        executor.shutdown();\n        try {\n            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {\n                executor.shutdownNow();\n            }\n        } catch (InterruptedException e) {\n            executor.shutdownNow();\n        }\n        \n        System.out.println("Final map: " + concurrentMap);\n    }\n}'
          }
        ],
        orderIndex: 4
      },
      {
        language: 'java',
        concept: 'frameworks',
        title: 'Spring Framework and Enterprise Development',
        description: 'Dependency injection, Spring Boot, REST APIs, and enterprise patterns',
        content: 'Spring Framework simplifies enterprise Java development through dependency injection, aspect-oriented programming, and comprehensive infrastructure support. Spring Boot provides auto-configuration, embedded servers, and production-ready features. Key concepts include IoC container, beans, annotations, and MVC pattern.',
        codeExamples: [
          {
            title: 'Spring Boot Application Structure',
            code: '// Main Application Class\n@SpringBootApplication\npublic class BookstoreApplication {\n    public static void main(String[] args) {\n        SpringApplication.run(BookstoreApplication.class, args);\n    }\n}\n\n// Entity/Model\n@Entity\n@Table(name = "books")\npublic class Book {\n    @Id\n    @GeneratedValue(strategy = GenerationType.IDENTITY)\n    private Long id;\n    \n    @Column(nullable = false)\n    private String title;\n    \n    @Column(nullable = false)\n    private String author;\n    \n    @Column(nullable = false)\n    private Double price;\n    \n    // Constructors\n    public Book() {}\n    \n    public Book(String title, String author, Double price) {\n        this.title = title;\n        this.author = author;\n        this.price = price;\n    }\n    \n    // Getters and Setters\n    public Long getId() { return id; }\n    public void setId(Long id) { this.id = id; }\n    \n    public String getTitle() { return title; }\n    public void setTitle(String title) { this.title = title; }\n    \n    public String getAuthor() { return author; }\n    public void setAuthor(String author) { this.author = author; }\n    \n    public Double getPrice() { return price; }\n    public void setPrice(Double price) { this.price = price; }\n}'
          },
          {
            title: 'REST Controller and Service Layer',
            code: '// Service Layer\n@Service\n@Transactional\npublic class BookService {\n    \n    @Autowired\n    private BookRepository bookRepository;\n    \n    public List<Book> getAllBooks() {\n        return bookRepository.findAll();\n    }\n    \n    public Optional<Book> getBookById(Long id) {\n        return bookRepository.findById(id);\n    }\n    \n    public Book saveBook(Book book) {\n        return bookRepository.save(book);\n    }\n    \n    public void deleteBook(Long id) {\n        bookRepository.deleteById(id);\n    }\n    \n    public List<Book> findBooksByAuthor(String author) {\n        return bookRepository.findByAuthorContainingIgnoreCase(author);\n    }\n}\n\n// Repository Interface\n@Repository\npublic interface BookRepository extends JpaRepository<Book, Long> {\n    List<Book> findByAuthorContainingIgnoreCase(String author);\n    List<Book> findByTitleContainingIgnoreCase(String title);\n}\n\n// REST Controller\n@RestController\n@RequestMapping("/api/books")\n@CrossOrigin(origins = "http://localhost:3000")\npublic class BookController {\n    \n    @Autowired\n    private BookService bookService;\n    \n    @GetMapping\n    public ResponseEntity<List<Book>> getAllBooks() {\n        List<Book> books = bookService.getAllBooks();\n        return ResponseEntity.ok(books);\n    }\n    \n    @GetMapping("/{id}")\n    public ResponseEntity<Book> getBookById(@PathVariable Long id) {\n        Optional<Book> book = bookService.getBookById(id);\n        return book.map(ResponseEntity::ok)\n                   .orElse(ResponseEntity.notFound().build());\n    }\n    \n    @PostMapping\n    public ResponseEntity<Book> createBook(@Valid @RequestBody Book book) {\n        Book savedBook = bookService.saveBook(book);\n        return ResponseEntity.status(HttpStatus.CREATED).body(savedBook);\n    }\n    \n    @PutMapping("/{id}")\n    public ResponseEntity<Book> updateBook(@PathVariable Long id, @Valid @RequestBody Book book) {\n        if (bookService.getBookById(id).isPresent()) {\n            book.setId(id);\n            Book updatedBook = bookService.saveBook(book);\n            return ResponseEntity.ok(updatedBook);\n        }\n        return ResponseEntity.notFound().build();\n    }\n    \n    @DeleteMapping("/{id}")\n    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {\n        if (bookService.getBookById(id).isPresent()) {\n            bookService.deleteBook(id);\n            return ResponseEntity.noContent().build();\n        }\n        return ResponseEntity.notFound().build();\n    }\n}'
          }
        ],
        orderIndex: 5
      }
    ];

    const aiTutorials: InsertTutorial[] = [
      {
        language: 'ai',
        concept: 'fundamentals',
        title: 'AI Fundamentals',
        description: 'Introduction to artificial intelligence and its applications',
        content: 'Artificial Intelligence (AI) is the simulation of human intelligence in machines. It includes machine learning, deep learning, natural language processing, computer vision, and robotics. AI systems can learn, reason, and make decisions.',
        codeExamples: [
          {
            title: 'Simple AI Decision Tree',
            code: 'import numpy as np\nfrom sklearn.tree import DecisionTreeClassifier\n\n# Sample data: [height, weight]\nX = [[180, 70], [160, 50], [175, 65], [155, 45]]\ny = [1, 0, 1, 0]  # 1: Male, 0: Female\n\n# Create and train model\nclf = DecisionTreeClassifier()\nclf.fit(X, y)\n\n# Make prediction\nresult = clf.predict([[170, 60]])\nprint(f"Prediction: {result[0]}")'
          },
          {
            title: 'Basic AI Concepts',
            code: '# AI vs Traditional Programming\n# Traditional: Data + Program → Output\n# AI: Data + Output → Program (Model)\n\n# Types of AI:\n# 1. Narrow AI (Current): Specific tasks\n# 2. General AI (Future): Human-level intelligence\n# 3. Super AI (Theoretical): Beyond human intelligence'
          }
        ],
        orderIndex: 1
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        title: 'Machine Learning Basics',
        description: 'Supervised and unsupervised learning algorithms',
        content: 'Machine Learning enables computers to learn patterns from data without explicit programming. Supervised learning uses labeled data, unsupervised learning finds hidden patterns, and reinforcement learning learns through rewards.',
        codeExamples: [
          {
            title: 'Linear Regression Example',
            code: 'import numpy as np\nfrom sklearn.linear_model import LinearRegression\nimport matplotlib.pyplot as plt\n\n# Sample data: study hours vs exam scores\nX = np.array([[1], [2], [3], [4], [5], [6]])\ny = np.array([50, 55, 65, 70, 80, 85])\n\n# Create and train model\nmodel = LinearRegression()\nmodel.fit(X, y)\n\n# Predict\nhours_studied = 7\nscore = model.predict([[hours_studied]])\nprint(f"Predicted score for {hours_studied} hours: {score[0]:.1f}")'
          },
          {
            title: 'Classification vs Regression',
            code: '# Classification: Predicting categories\n# Examples: Email spam detection, image recognition\n# Output: Discrete values (0/1, cat/dog/bird)\n\n# Regression: Predicting continuous values\n# Examples: House prices, stock prices, temperature\n# Output: Continuous values (123.45, 67.8)\n\n# Common algorithms:\n# - Decision Trees: Easy to interpret\n# - Random Forest: Multiple decision trees\n# - SVM: Support Vector Machines\n# - Neural Networks: Brain-inspired models'
          }
        ],
        orderIndex: 2
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        title: 'Deep Learning and Neural Networks',
        description: 'Neural networks, CNNs, and RNNs with TensorFlow',
        content: 'Deep Learning uses artificial neural networks with multiple layers to learn complex patterns. Convolutional Neural Networks (CNNs) excel at image processing, while Recurrent Neural Networks (RNNs) handle sequential data.',
        codeExamples: [
          {
            title: 'Simple Neural Network with TensorFlow',
            code: 'import tensorflow as tf\nfrom tensorflow.keras.models import Sequential\nfrom tensorflow.keras.layers import Dense\n\n# Create a simple neural network\nmodel = Sequential([\n    Dense(64, activation="relu", input_shape=(10,)),\n    Dense(32, activation="relu"),\n    Dense(1, activation="sigmoid")\n])\n\n# Compile the model\nmodel.compile(optimizer="adam",\n              loss="binary_crossentropy",\n              metrics=["accuracy"])\n\nprint("Neural network created!")\nmodel.summary()'
          },
          {
            title: 'CNN for Image Classification',
            code: 'import tensorflow as tf\nfrom tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense\n\n# CNN for image classification\nmodel = tf.keras.Sequential([\n    Conv2D(32, (3, 3), activation="relu", input_shape=(28, 28, 1)),\n    MaxPooling2D(2, 2),\n    Conv2D(64, (3, 3), activation="relu"),\n    MaxPooling2D(2, 2),\n    Flatten(),\n    Dense(128, activation="relu"),\n    Dense(10, activation="softmax")  # 10 classes\n])\n\nprint("CNN model for image classification ready!")'
          }
        ],
        orderIndex: 3
      },
      {
        language: 'ai',
        concept: 'nlp',
        title: 'Natural Language Processing',
        description: 'Text processing, sentiment analysis, and language models',
        content: 'Natural Language Processing (NLP) enables computers to understand, interpret, and generate human language. Key techniques include tokenization, part-of-speech tagging, named entity recognition, sentiment analysis, and language models like transformers. Modern NLP uses deep learning approaches for tasks like translation, summarization, and question answering.',
        codeExamples: [
          {
            title: 'Text Processing with NLTK',
            code: 'import nltk\nfrom nltk.tokenize import word_tokenize, sent_tokenize\nfrom nltk.corpus import stopwords\nfrom nltk.stem import PorterStemmer\nfrom collections import Counter\n\n# Download required NLTK data\n# nltk.download(\'punkt\')\n# nltk.download(\'stopwords\')\n\ntext = "Natural Language Processing is fascinating! It helps computers understand human language."\n\n# Tokenization\nwords = word_tokenize(text)\nsentences = sent_tokenize(text)\nprint(f"Words: {words}")\nprint(f"Sentences: {sentences}")\n\n# Remove stopwords and stem\nstemmer = PorterStemmer()\nstop_words = set(stopwords.words(\'english\'))\nfiltered_words = [stemmer.stem(word.lower()) for word in words \n                  if word.lower() not in stop_words and word.isalpha()]\nprint(f"Processed words: {filtered_words}")\n\n# Word frequency\nword_freq = Counter(filtered_words)\nprint(f"Most common: {word_freq.most_common(3)}")'
          },
          {
            title: 'Sentiment Analysis with TextBlob',
            code: 'from textblob import TextBlob\nimport re\n\ndef analyze_sentiment(text):\n    # Clean text\n    text = re.sub(r\'[^a-zA-Z\\s]\', \'\', text)\n    \n    # Create TextBlob object\n    blob = TextBlob(text)\n    \n    # Get sentiment\n    polarity = blob.sentiment.polarity\n    subjectivity = blob.sentiment.subjectivity\n    \n    # Determine sentiment category\n    if polarity > 0.1:\n        sentiment = "Positive"\n    elif polarity < -0.1:\n        sentiment = "Negative"\n    else:\n        sentiment = "Neutral"\n    \n    return {\n        \'text\': text,\n        \'sentiment\': sentiment,\n        \'polarity\': round(polarity, 2),\n        \'subjectivity\': round(subjectivity, 2)\n    }\n\n# Example usage\ntexts = [\n    "I love this product! It works perfectly.",\n    "This movie was terrible and boring.",\n    "The weather is okay today."\n]\n\nfor text in texts:\n    result = analyze_sentiment(text)\n    print(f"Text: {result[\'text\']}")\n    print(f"Sentiment: {result[\'sentiment\']} (Polarity: {result[\'polarity\']})")\n    print("---")'
          },
          {
            title: 'Building a Simple Chatbot',
            code: 'import random\nimport re\n\nclass SimpleChatbot:\n    def __init__(self):\n        self.patterns = {\n            r\'hello|hi|hey\': [\n                "Hello! How can I help you?",\n                "Hi there! What can I do for you?",\n                "Hey! Nice to meet you!"\n            ],\n            r\'how are you\': [\n                "I\'m doing great! How about you?",\n                "I\'m fine, thank you for asking!",\n                "All good! Thanks for asking."\n            ],\n            r\'what.*your.*name\': [\n                "I\'m a simple chatbot created with Python!",\n                "You can call me PyBot!",\n                "I\'m your friendly AI assistant!"\n            ],\n            r\'bye|goodbye|exit\': [\n                "Goodbye! Have a great day!",\n                "See you later!",\n                "Bye! Come back anytime!"\n            ],\n            r\'help\': [\n                "I can chat with you! Try saying hello, asking how I am, or say goodbye.",\n                "Just talk to me naturally! I understand basic greetings and questions."\n            ]\n        }\n        \n        self.default_responses = [\n            "That\'s interesting! Tell me more.",\n            "I see. Can you elaborate?",\n            "I\'m not sure I understand. Could you rephrase?",\n            "Hmm, let me think about that..."\n        ]\n    \n    def get_response(self, user_input):\n        user_input = user_input.lower().strip()\n        \n        for pattern, responses in self.patterns.items():\n            if re.search(pattern, user_input):\n                return random.choice(responses)\n        \n        return random.choice(self.default_responses)\n    \n    def chat(self):\n        print("Chatbot: Hello! I\'m here to chat. Type \'bye\' to exit.")\n        \n        while True:\n            user_input = input("You: ")\n            \n            if re.search(r\'bye|goodbye|exit\', user_input.lower()):\n                print("Chatbot:", self.get_response(user_input))\n                break\n            \n            response = self.get_response(user_input)\n            print("Chatbot:", response)\n\n# Usage\n# bot = SimpleChatbot()\n# bot.chat()'
          }
        ],
        orderIndex: 4
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        title: 'Computer Vision',
        description: 'Image processing, object detection, and visual recognition with OpenCV',
        content: 'Computer Vision enables machines to interpret and understand visual information from images and videos. Key techniques include image preprocessing, feature detection, object recognition, and deep learning approaches like CNNs. Applications range from medical imaging to autonomous vehicles and augmented reality.',
        codeExamples: [
          {
            title: 'Image Processing with OpenCV',
            code: 'import cv2\nimport numpy as np\nimport matplotlib.pyplot as plt\n\n# Read an image\n# img = cv2.imread(\'sample_image.jpg\')\n# For demonstration, create a sample image\nimg = np.zeros((300, 400, 3), dtype=np.uint8)\ncv2.rectangle(img, (50, 50), (200, 150), (255, 0, 0), -1)\ncv2.circle(img, (300, 200), 50, (0, 255, 0), -1)\n\n# Convert BGR to RGB for matplotlib\nimg_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)\n\n# Apply various transformations\ngray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)\nblurred = cv2.GaussianBlur(gray, (15, 15), 0)\nedges = cv2.Canny(blurred, 50, 150)\n\n# Create subplot to show results\nfig, axes = plt.subplots(2, 2, figsize=(10, 8))\naxes[0,0].imshow(img_rgb)\naxes[0,0].set_title(\'Original Image\')\naxes[0,0].axis(\'off\')\n\naxes[0,1].imshow(gray, cmap=\'gray\')\naxes[0,1].set_title(\'Grayscale\')\naxes[0,1].axis(\'off\')\n\naxes[1,0].imshow(blurred, cmap=\'gray\')\naxes[1,0].set_title(\'Blurred\')\naxes[1,0].axis(\'off\')\n\naxes[1,1].imshow(edges, cmap=\'gray\')\naxes[1,1].set_title(\'Edge Detection\')\naxes[1,1].axis(\'off\')\n\nplt.tight_layout()\nprint("Image processing completed!")'
          },
          {
            title: 'Object Detection and Contours',
            code: 'import cv2\nimport numpy as np\n\ndef detect_shapes(image):\n    # Convert to grayscale\n    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)\n    \n    # Apply threshold to get binary image\n    _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)\n    \n    # Find contours\n    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)\n    \n    # Create output image\n    output = image.copy()\n    \n    for contour in contours:\n        # Calculate area and perimeter\n        area = cv2.contourArea(contour)\n        perimeter = cv2.arcLength(contour, True)\n        \n        if area > 1000:  # Filter small objects\n            # Approximate contour to polygon\n            approx = cv2.approxPolyDP(contour, 0.02 * perimeter, True)\n            \n            # Determine shape based on number of vertices\n            vertices = len(approx)\n            \n            # Get bounding box\n            x, y, w, h = cv2.boundingRect(contour)\n            \n            # Classify shape\n            if vertices == 3:\n                shape = "Triangle"\n                color = (0, 255, 0)  # Green\n            elif vertices == 4:\n                aspect_ratio = w / float(h)\n                if 0.95 <= aspect_ratio <= 1.05:\n                    shape = "Square"\n                else:\n                    shape = "Rectangle"\n                color = (255, 0, 0)  # Blue\n            elif vertices > 4:\n                shape = "Circle"\n                color = (0, 0, 255)  # Red\n            else:\n                shape = "Unknown"\n                color = (128, 128, 128)  # Gray\n            \n            # Draw contour and label\n            cv2.drawContours(output, [contour], -1, color, 2)\n            cv2.putText(output, f"{shape} (A:{int(area)})", \n                       (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, \n                       0.5, color, 1)\n    \n    return output\n\n# Create sample image with shapes\nimg = np.zeros((400, 600, 3), dtype=np.uint8)\n\n# Draw different shapes\ncv2.rectangle(img, (50, 50), (150, 150), (255, 255, 255), -1)  # Square\ncv2.rectangle(img, (200, 50), (350, 100), (255, 255, 255), -1)  # Rectangle\n\n# Triangle points\ntriangle_pts = np.array([[400, 50], [450, 150], [350, 150]], np.int32)\ncv2.fillPoly(img, [triangle_pts], (255, 255, 255))\n\n# Circle\ncv2.circle(img, (100, 300), 50, (255, 255, 255), -1)\n\n# Detect and label shapes\nresult = detect_shapes(img)\nprint("Shape detection completed!")'
          },
          {
            title: 'Face Detection with Haar Cascades',
            code: 'import cv2\nimport numpy as np\n\nclass FaceDetector:\n    def __init__(self):\n        # Load pre-trained Haar cascade for face detection\n        # Note: You need to download haarcascade_frontalface_default.xml\n        self.face_cascade = cv2.CascadeClassifier(\n            cv2.data.haarcascades + \'haarcascade_frontalface_default.xml\'\n        )\n        self.eye_cascade = cv2.CascadeClassifier(\n            cv2.data.haarcascades + \'haarcascade_eye.xml\'\n        )\n    \n    def detect_faces(self, image):\n        # Convert to grayscale\n        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)\n        \n        # Detect faces\n        faces = self.face_cascade.detectMultiScale(\n            gray, \n            scaleFactor=1.1, \n            minNeighbors=5, \n            minSize=(30, 30)\n        )\n        \n        # Draw rectangles around faces\n        for (x, y, w, h) in faces:\n            cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)\n            \n            # Region of interest for eyes within face\n            roi_gray = gray[y:y+h, x:x+w]\n            roi_color = image[y:y+h, x:x+w]\n            \n            # Detect eyes within face region\n            eyes = self.eye_cascade.detectMultiScale(\n                roi_gray, \n                scaleFactor=1.1, \n                minNeighbors=3\n            )\n            \n            for (ex, ey, ew, eh) in eyes:\n                cv2.rectangle(roi_color, (ex, ey), (ex+ew, ey+eh), (0, 255, 0), 1)\n            \n            # Add label\n            cv2.putText(image, f\'Face {len(faces)}\', \n                       (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, \n                       0.7, (255, 0, 0), 2)\n        \n        return image, len(faces)\n    \n    def process_video(self, source=0):\n        """Process video stream (0 for webcam)"""\n        cap = cv2.VideoCapture(source)\n        \n        while True:\n            ret, frame = cap.read()\n            if not ret:\n                break\n            \n            # Detect faces in frame\n            processed_frame, face_count = self.detect_faces(frame.copy())\n            \n            # Display frame\n            cv2.putText(processed_frame, f\'Faces detected: {face_count}\', \n                       (10, 30), cv2.FONT_HERSHEY_SIMPLEX, \n                       1, (255, 255, 255), 2)\n            \n            cv2.imshow(\'Face Detection\', processed_frame)\n            \n            # Press \'q\' to quit\n            if cv2.waitKey(1) & 0xFF == ord(\'q\'):\n                break\n        \n        cap.release()\n        cv2.destroyAllWindows()\n\n# Usage example\n# detector = FaceDetector()\n# For webcam: detector.process_video(0)\n# For image: result, count = detector.detect_faces(your_image)\nprint("Face detection system ready!")'
          }
        ],
        orderIndex: 5
      }
    ];

    // Add tutorials
    [...pythonTutorials, ...javaTutorials, ...aiTutorials].forEach(tutorial => {
      const id = randomUUID();
      this.tutorials.set(id, { 
        ...tutorial, 
        id, 
        description: tutorial.description || null,
        codeExamples: tutorial.codeExamples || [],
        createdAt: new Date() 
      });
    });

    // Comprehensive quiz questions
    const pythonQuestions: InsertQuizQuestion[] = [
      // Python Basics
      {
        language: 'python',
        concept: 'basics',
        question: 'Which of the following is used to define a block of code in Python?',
        options: ['Curly braces {}', 'Parentheses ()', 'Indentation', 'Square brackets []'],
        correctAnswer: 2,
        explanation: 'Python uses indentation to define blocks of code instead of braces like other languages.',
        difficulty: 'beginner',
        orderIndex: 1
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'What is the output of: print(type(5.0))?',
        options: ['<class \'int\'>', '<class \'float\'>', '<class \'double\'>', '<class \'number\'>'],
        correctAnswer: 1,
        explanation: 'In Python, 5.0 is a floating-point number, so its type is float.',
        difficulty: 'beginner',
        orderIndex: 2
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'Which operator is used for floor division in Python?',
        options: ['/', '//', '%', '**'],
        correctAnswer: 1,
        explanation: 'The // operator performs floor division, returning the quotient without the remainder.',
        difficulty: 'beginner',
        orderIndex: 3
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'What will len([1, 2, 3, [4, 5]]) return?',
        options: ['3', '4', '5', '2'],
        correctAnswer: 1,
        explanation: 'The len() function returns the number of top-level items. The nested list [4, 5] counts as one item.',
        difficulty: 'intermediate',
        orderIndex: 4
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'Which of these is a valid variable name in Python?',
        options: ['2myvar', 'my-var', '_myvar', 'def'],
        correctAnswer: 2,
        explanation: 'Variable names can start with letters or underscore, but not numbers or hyphens. "def" is a reserved keyword.',
        difficulty: 'beginner',
        orderIndex: 5
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'What does the range(5) function produce?',
        options: ['[0, 1, 2, 3, 4, 5]', '[1, 2, 3, 4, 5]', '[0, 1, 2, 3, 4]', 'A range object from 0 to 4'],
        correctAnswer: 3,
        explanation: 'range(5) creates a range object containing numbers 0 through 4 (5 is excluded).',
        difficulty: 'beginner',
        orderIndex: 6
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'What is the result of: "Hello" + "World"?',
        options: ['HelloWorld', 'Hello World', 'Error', 'Hello+World'],
        correctAnswer: 0,
        explanation: 'String concatenation with + operator joins strings together without spaces.',
        difficulty: 'beginner',
        orderIndex: 7
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'Which statement correctly checks if x is between 10 and 20 (inclusive)?',
        options: ['10 <= x <= 20', 'x >= 10 and x <= 20', 'Both A and B', 'x between 10 and 20'],
        correctAnswer: 2,
        explanation: 'Python supports chained comparisons (10 <= x <= 20) and traditional boolean operators.',
        difficulty: 'intermediate',
        orderIndex: 8
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'What is the output of: print(bool([]))?',
        options: ['True', 'False', 'Error', '[]'],
        correctAnswer: 1,
        explanation: 'Empty containers (lists, tuples, dicts, sets, strings) evaluate to False in boolean context.',
        difficulty: 'intermediate',
        orderIndex: 9
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'Which loop would you use to iterate over both index and value of a list?',
        options: ['for i in list:', 'for i in range(len(list)):', 'for i, value in enumerate(list):', 'while i < len(list):'],
        correctAnswer: 2,
        explanation: 'enumerate() returns both the index and value for each item in an iterable.',
        difficulty: 'intermediate',
        orderIndex: 10
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'What does the "pass" statement do?',
        options: ['Ends the program', 'Skips to next iteration', 'Does nothing (placeholder)', 'Passes a value to function'],
        correctAnswer: 2,
        explanation: 'The pass statement is a null operation - it does nothing and serves as a placeholder.',
        difficulty: 'beginner',
        orderIndex: 11
      },
      {
        language: 'python',
        concept: 'basics',
        question: 'What is the correct way to create a multi-line string?',
        options: ['Using \\n in single quotes', 'Using triple quotes """..."""', 'Using multiple + operations', 'All of the above'],
        correctAnswer: 3,
        explanation: 'Python supports multiple ways to create multi-line strings, including triple quotes, \\n, and concatenation.',
        difficulty: 'intermediate',
        orderIndex: 12
      },
      
      // Python Data Types  
      {
        language: 'python',
        concept: 'datatypes',
        question: 'Which data type is mutable in Python?',
        options: ['tuple', 'string', 'list', 'integer'],
        correctAnswer: 2,
        explanation: 'Lists are mutable in Python, meaning you can change their contents after creation.',
        difficulty: 'beginner',
        orderIndex: 13
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'What is the difference between a list and a tuple?',
        options: ['Lists are faster', 'Tuples are mutable, lists are immutable', 'Lists are mutable, tuples are immutable', 'No difference'],
        correctAnswer: 2,
        explanation: 'The key difference is mutability: lists can be changed after creation, tuples cannot.',
        difficulty: 'beginner',
        orderIndex: 14
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'What will {1, 2, 2, 3, 3, 3} create?',
        options: ['{1, 2, 2, 3, 3, 3}', '{1, 2, 3}', 'Error', '[1, 2, 3]'],
        correctAnswer: 1,
        explanation: 'Sets automatically remove duplicates, so this creates a set with unique values {1, 2, 3}.',
        difficulty: 'beginner',
        orderIndex: 15
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'How do you access the value associated with key "name" in dict d?',
        options: ['d.name', 'd["name"]', 'd.get("name")', 'Both B and C'],
        correctAnswer: 3,
        explanation: 'Both d["name"] and d.get("name") work, but get() returns None if key doesn\'t exist instead of raising an error.',
        difficulty: 'intermediate',
        orderIndex: 16
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'What is the result of: "123".isdigit()?',
        options: ['True', 'False', 'Error', '123'],
        correctAnswer: 0,
        explanation: 'The isdigit() method returns True if all characters in the string are digits.',
        difficulty: 'beginner',
        orderIndex: 17
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'Which method adds an element to the end of a list?',
        options: ['add()', 'append()', 'insert()', 'extend()'],
        correctAnswer: 1,
        explanation: 'append() adds a single element to the end of a list.',
        difficulty: 'beginner',
        orderIndex: 18
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'What does list.extend([1, 2, 3]) do?',
        options: ['Adds [1, 2, 3] as single element', 'Adds 1, 2, 3 as separate elements', 'Replaces list with [1, 2, 3]', 'Creates new list'],
        correctAnswer: 1,
        explanation: 'extend() adds all elements from the iterable to the end of the list individually.',
        difficulty: 'intermediate',
        orderIndex: 19
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'How do you create an empty dictionary?',
        options: ['{}', 'dict()', 'new dict()', 'Both A and B'],
        correctAnswer: 3,
        explanation: 'Both {} and dict() create empty dictionaries in Python.',
        difficulty: 'beginner',
        orderIndex: 20
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'What is the output of: len("Hello\\nWorld")?',
        options: ['10', '11', '12', 'Error'],
        correctAnswer: 1,
        explanation: 'The \\n is a single newline character, so the total length is 11 characters.',
        difficulty: 'intermediate',
        orderIndex: 21
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'Which operation is NOT supported by tuples?',
        options: ['Indexing (t[0])', 'Slicing (t[1:3])', 'Appending (t.append())', 'Length (len(t))'],
        correctAnswer: 2,
        explanation: 'Tuples are immutable, so they don\'t have methods that modify them like append().',
        difficulty: 'intermediate',
        orderIndex: 22
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'What is the result of: type(None)?',
        options: ['<class \'None\'>', '<class \'NoneType\'>', '<class \'null\'>', 'Error'],
        correctAnswer: 1,
        explanation: 'None is of type NoneType, which is Python\'s null value representation.',
        difficulty: 'intermediate',
        orderIndex: 23
      },
      {
        language: 'python',
        concept: 'datatypes',
        question: 'Which creates a shallow copy of list a?',
        options: ['a.copy()', 'a[:]', 'list(a)', 'All of the above'],
        correctAnswer: 3,
        explanation: 'All these methods create a shallow copy of the list: copy(), slicing [:], and list() constructor.',
        difficulty: 'advanced',
        orderIndex: 24
      },

      // Python Functions
      {
        language: 'python',
        concept: 'functions',
        question: 'Which of the following is the correct way to define a function in Python?',
        options: ['function myFunction() { }', 'def myFunction():', 'func myFunction() { }', 'create myFunction():'],
        correctAnswer: 1,
        explanation: 'In Python, functions are defined using the "def" keyword followed by the function name and parentheses.',
        difficulty: 'beginner',
        orderIndex: 25
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What happens if a function doesn\'t have a return statement?',
        options: ['Error occurs', 'Returns 0', 'Returns None', 'Returns empty string'],
        correctAnswer: 2,
        explanation: 'Functions without explicit return statements automatically return None.',
        difficulty: 'beginner',
        orderIndex: 26
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What is *args used for in function definitions?',
        options: ['Required arguments', 'Keyword arguments', 'Variable number of arguments', 'Default arguments'],
        correctAnswer: 2,
        explanation: '*args allows a function to accept any number of positional arguments as a tuple.',
        difficulty: 'intermediate',
        orderIndex: 27
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What is **kwargs used for?',
        options: ['Variable positional args', 'Variable keyword args', 'Required keyword args', 'Default values'],
        correctAnswer: 1,
        explanation: '**kwargs allows a function to accept any number of keyword arguments as a dictionary.',
        difficulty: 'intermediate',
        orderIndex: 28
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What is a lambda function?',
        options: ['A named function', 'An anonymous function', 'A recursive function', 'A built-in function'],
        correctAnswer: 1,
        explanation: 'Lambda functions are anonymous (unnamed) functions that can be defined inline.',
        difficulty: 'intermediate',
        orderIndex: 29
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What does this lambda do: lambda x: x * 2?',
        options: ['Multiplies x by 2', 'Adds 2 to x', 'Divides x by 2', 'Returns x and 2'],
        correctAnswer: 0,
        explanation: 'This lambda function takes one argument x and returns x multiplied by 2.',
        difficulty: 'beginner',
        orderIndex: 30
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What is the scope of variables defined inside a function?',
        options: ['Global scope', 'Local scope', 'Module scope', 'Class scope'],
        correctAnswer: 1,
        explanation: 'Variables defined inside a function have local scope and are only accessible within that function.',
        difficulty: 'intermediate',
        orderIndex: 31
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'How do you make a variable global inside a function?',
        options: ['Use global keyword', 'Use public keyword', 'Use static keyword', 'Use extern keyword'],
        correctAnswer: 0,
        explanation: 'The global keyword is used to modify global variables inside a function.',
        difficulty: 'intermediate',
        orderIndex: 32
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What is function overloading in Python?',
        options: ['Not supported', 'Supported with decorators', 'Built-in feature', 'Requires special syntax'],
        correctAnswer: 0,
        explanation: 'Python doesn\'t support traditional function overloading. The last defined function with the same name overwrites previous ones.',
        difficulty: 'advanced',
        orderIndex: 33
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What is a closure in Python?',
        options: ['A nested function that accesses outer variables', 'A function that closes files', 'A function without parameters', 'A recursive function'],
        correctAnswer: 0,
        explanation: 'A closure is a nested function that has access to variables from its outer (enclosing) scope.',
        difficulty: 'advanced',
        orderIndex: 34
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'What does the @property decorator do?',
        options: ['Makes a method private', 'Allows method to be called like an attribute', 'Caches method results', 'Makes method static'],
        correctAnswer: 1,
        explanation: 'The @property decorator allows a method to be accessed like an attribute, providing getter functionality.',
        difficulty: 'advanced',
        orderIndex: 35
      },
      {
        language: 'python',
        concept: 'functions',
        question: 'Which is correct for default parameter values?',
        options: ['def func(a=[], b=5):', 'def func(a=None, b=5):', 'def func(b=5, a):', 'def func(*args, a=5):'],
        correctAnswer: 1,
        explanation: 'Default parameters should avoid mutable objects like []. Using None and then checking inside the function is safer.',
        difficulty: 'advanced',
        orderIndex: 36
      },

      // Python Modules
      {
        language: 'python',
        concept: 'modules',
        question: 'How do you import a specific function from a module?',
        options: ['import module.function', 'from module import function', 'import function from module', 'module.import function'],
        correctAnswer: 1,
        explanation: 'The "from module import function" syntax imports specific functions from a module.',
        difficulty: 'beginner',
        orderIndex: 37
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'What does "import math as m" do?',
        options: ['Imports math with alias m', 'Imports m from math', 'Creates module m', 'Renames math module'],
        correctAnswer: 0,
        explanation: 'This imports the math module and gives it an alias "m" for shorter reference.',
        difficulty: 'beginner',
        orderIndex: 38
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'What is the purpose of __init__.py file?',
        options: ['Initialize variables', 'Mark directory as package', 'Main entry point', 'Configuration file'],
        correctAnswer: 1,
        explanation: '__init__.py marks a directory as a Python package and can contain initialization code.',
        difficulty: 'intermediate',
        orderIndex: 39
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'How do you check if a module is available?',
        options: ['Use try/except with import', 'Use hasattr()', 'Use isinstance()', 'Use type()'],
        correctAnswer: 0,
        explanation: 'The best way is to use try/except around the import statement to catch ImportError.',
        difficulty: 'intermediate',
        orderIndex: 40
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'What does sys.path contain?',
        options: ['File paths', 'Module search paths', 'System paths', 'User paths'],
        correctAnswer: 1,
        explanation: 'sys.path is a list of directories where Python searches for modules.',
        difficulty: 'intermediate',
        orderIndex: 41
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'What is the difference between import and from...import?',
        options: ['No difference', 'import loads entire module, from...import loads specific items', 'from...import is faster', 'import is deprecated'],
        correctAnswer: 1,
        explanation: 'import loads the entire module into current namespace, while from...import loads only specified items.',
        difficulty: 'intermediate',
        orderIndex: 42
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'What does if __name__ == "__main__": do?',
        options: ['Checks module name', 'Runs code only when script is executed directly', 'Checks for main function', 'Validates imports'],
        correctAnswer: 1,
        explanation: 'This condition ensures code runs only when the script is executed directly, not when imported.',
        difficulty: 'intermediate',
        orderIndex: 43
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'How do you install third-party packages?',
        options: ['Using apt', 'Using pip', 'Using npm', 'Using yarn'],
        correctAnswer: 1,
        explanation: 'pip (Pip Installs Packages) is Python\'s package installer for third-party packages.',
        difficulty: 'beginner',
        orderIndex: 44
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'What is a virtual environment?',
        options: ['VM for Python', 'Isolated Python environment', 'Cloud environment', 'Testing environment'],
        correctAnswer: 1,
        explanation: 'A virtual environment is an isolated Python environment with its own packages and dependencies.',
        difficulty: 'intermediate',
        orderIndex: 45
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'Which command creates a virtual environment?',
        options: ['python -m venv myenv', 'python create myenv', 'pip install myenv', 'virtual myenv'],
        correctAnswer: 0,
        explanation: 'python -m venv myenv creates a new virtual environment named "myenv".',
        difficulty: 'intermediate',
        orderIndex: 46
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'What file lists project dependencies?',
        options: ['dependencies.txt', 'requirements.txt', 'packages.txt', 'modules.txt'],
        correctAnswer: 1,
        explanation: 'requirements.txt is the standard file for listing Python project dependencies.',
        difficulty: 'beginner',
        orderIndex: 47
      },
      {
        language: 'python',
        concept: 'modules',
        question: 'How do you reload a module in Python?',
        options: ['reload(module)', 'importlib.reload(module)', 'module.reload()', 'import module again'],
        correctAnswer: 1,
        explanation: 'importlib.reload() is used to reload a module that has already been imported.',
        difficulty: 'advanced',
        orderIndex: 48
      },

      // Python OOP
      {
        language: 'python',
        concept: 'oop',
        question: 'How do you define a class in Python?',
        options: ['class MyClass:', 'class MyClass():', 'def MyClass:', 'create MyClass:'],
        correctAnswer: 0,
        explanation: 'Classes are defined using the "class" keyword followed by the class name and a colon.',
        difficulty: 'beginner',
        orderIndex: 49
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What is __init__ method used for?',
        options: ['Initialize class', 'Constructor method', 'Destructor method', 'Static method'],
        correctAnswer: 1,
        explanation: '__init__ is the constructor method called when creating new instances of a class.',
        difficulty: 'beginner',
        orderIndex: 50
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What does "self" represent in Python class methods?',
        options: ['Class name', 'Current instance', 'Parent class', 'Method name'],
        correctAnswer: 1,
        explanation: '"self" refers to the current instance of the class and must be the first parameter in instance methods.',
        difficulty: 'beginner',
        orderIndex: 51
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'How do you implement inheritance?',
        options: ['class Child(Parent):', 'class Child extends Parent:', 'class Child inherits Parent:', 'class Child -> Parent:'],
        correctAnswer: 0,
        explanation: 'Inheritance is implemented by putting the parent class name in parentheses after the child class name.',
        difficulty: 'beginner',
        orderIndex: 52
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What is method overriding?',
        options: ['Adding new methods', 'Redefining parent class methods', 'Removing methods', 'Renaming methods'],
        correctAnswer: 1,
        explanation: 'Method overriding allows a child class to provide a different implementation of a parent class method.',
        difficulty: 'intermediate',
        orderIndex: 53
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What is the super() function used for?',
        options: ['Create superclass', 'Access parent class methods', 'Make method superior', 'Delete parent class'],
        correctAnswer: 1,
        explanation: 'super() is used to access methods and properties from the parent class.',
        difficulty: 'intermediate',
        orderIndex: 54
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What makes a method private in Python?',
        options: ['private keyword', 'Starting with underscore _', 'Starting with double underscore __', 'Using @private decorator'],
        correctAnswer: 2,
        explanation: 'Methods starting with double underscore __ are name-mangled and treated as private.',
        difficulty: 'intermediate',
        orderIndex: 55
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What is a class variable?',
        options: ['Variable inside __init__', 'Variable shared by all instances', 'Variable in class method', 'Variable with class scope'],
        correctAnswer: 1,
        explanation: 'Class variables are defined at class level and shared by all instances of the class.',
        difficulty: 'intermediate',
        orderIndex: 56
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What decorator makes a method static?',
        options: ['@static', '@staticmethod', '@class', '@classmethod'],
        correctAnswer: 1,
        explanation: '@staticmethod decorator makes a method static - it doesn\'t receive self or cls as first argument.',
        difficulty: 'intermediate',
        orderIndex: 57
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What\'s the difference between @staticmethod and @classmethod?',
        options: ['No difference', 'staticmethod gets no special first arg, classmethod gets cls', 'staticmethod is faster', 'classmethod is deprecated'],
        correctAnswer: 1,
        explanation: '@staticmethod receives no special first argument, while @classmethod receives cls (the class) as first argument.',
        difficulty: 'advanced',
        orderIndex: 58
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What is multiple inheritance?',
        options: ['One class, multiple objects', 'Class inheriting from multiple parents', 'Multiple classes inheriting from one parent', 'Not supported in Python'],
        correctAnswer: 1,
        explanation: 'Multiple inheritance allows a class to inherit from multiple parent classes.',
        difficulty: 'advanced',
        orderIndex: 59
      },
      {
        language: 'python',
        concept: 'oop',
        question: 'What is the Method Resolution Order (MRO)?',
        options: ['Order of method calls', 'Order Python searches for methods in inheritance', 'Order methods are defined', 'Order of method parameters'],
        correctAnswer: 1,
        explanation: 'MRO determines the order in which Python searches for methods in the inheritance hierarchy.',
        difficulty: 'advanced',
        orderIndex: 60
      },

      // Python Libraries
      {
        language: 'python',
        concept: 'libraries',
        question: 'Which library is commonly used for numerical computing?',
        options: ['NumPy', 'Pandas', 'Matplotlib', 'Requests'],
        correctAnswer: 0,
        explanation: 'NumPy is the fundamental library for numerical computing in Python, providing support for arrays and mathematical functions.',
        difficulty: 'beginner',
        orderIndex: 61
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'What is Pandas primarily used for?',
        options: ['Web scraping', 'Data analysis and manipulation', 'Image processing', 'Network programming'],
        correctAnswer: 1,
        explanation: 'Pandas is designed for data analysis and manipulation, providing data structures like DataFrame.',
        difficulty: 'beginner',
        orderIndex: 62
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'Which library is used for creating plots and visualizations?',
        options: ['NumPy', 'Pandas', 'Matplotlib', 'Requests'],
        correctAnswer: 2,
        explanation: 'Matplotlib is the primary library for creating static, animated, and interactive visualizations.',
        difficulty: 'beginner',
        orderIndex: 63
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'What is the Requests library used for?',
        options: ['Database requests', 'HTTP requests', 'File requests', 'Memory requests'],
        correctAnswer: 1,
        explanation: 'The Requests library is used for making HTTP requests in an easy, human-readable way.',
        difficulty: 'beginner',
        orderIndex: 64
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'Which framework is commonly used for web development?',
        options: ['NumPy', 'Django', 'Matplotlib', 'Pandas'],
        correctAnswer: 1,
        explanation: 'Django is a high-level Python web framework that encourages rapid development.',
        difficulty: 'beginner',
        orderIndex: 65
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'What is Flask?',
        options: ['Database library', 'Micro web framework', 'Testing library', 'Data analysis library'],
        correctAnswer: 1,
        explanation: 'Flask is a lightweight, micro web framework for Python that\'s easy to get started with.',
        difficulty: 'beginner',
        orderIndex: 66
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'Which library is used for machine learning?',
        options: ['scikit-learn', 'BeautifulSoup', 'pygame', 'tkinter'],
        correctAnswer: 0,
        explanation: 'scikit-learn is a popular machine learning library that provides simple tools for data analysis.',
        difficulty: 'intermediate',
        orderIndex: 67
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'What is BeautifulSoup used for?',
        options: ['Web scraping', 'Data analysis', 'GUI development', 'Testing'],
        correctAnswer: 0,
        explanation: 'BeautifulSoup is used for web scraping - parsing HTML and XML documents.',
        difficulty: 'intermediate',
        orderIndex: 68
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'Which library provides support for regular expressions?',
        options: ['re', 'regex', 'pattern', 'match'],
        correctAnswer: 0,
        explanation: 'The "re" module is Python\'s built-in library for working with regular expressions.',
        difficulty: 'intermediate',
        orderIndex: 69
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'What is TensorFlow?',
        options: ['Web framework', 'Deep learning library', 'Database library', 'Testing framework'],
        correctAnswer: 1,
        explanation: 'TensorFlow is an open-source deep learning library developed by Google.',
        difficulty: 'intermediate',
        orderIndex: 70
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'Which library is used for image processing?',
        options: ['PIL/Pillow', 'NumPy', 'Pandas', 'Requests'],
        correctAnswer: 0,
        explanation: 'PIL (Python Imaging Library) or its modern fork Pillow is used for image processing.',
        difficulty: 'intermediate',
        orderIndex: 71
      },
      {
        language: 'python',
        concept: 'libraries',
        question: 'What is pytest used for?',
        options: ['Performance testing', 'Unit testing', 'Load testing', 'Security testing'],
        correctAnswer: 1,
        explanation: 'pytest is a mature testing framework for Python that makes it easy to write simple tests.',
        difficulty: 'intermediate',
        orderIndex: 72
      }
    ];

    const javaQuestions: InsertQuizQuestion[] = [
      // Java Basics
      {
        language: 'java',
        concept: 'basics',
        question: 'What is the entry point method in a Java application?',
        options: ['start()', 'main()', 'run()', 'execute()'],
        correctAnswer: 1,
        explanation: 'The main() method serves as the entry point for Java applications.',
        difficulty: 'beginner',
        orderIndex: 73
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'Which of these is a valid Java identifier?',
        options: ['2myVariable', 'my-variable', '_myVariable', 'class'],
        correctAnswer: 2,
        explanation: 'Java identifiers can start with letters, underscore, or dollar sign, but not digits or hyphens.',
        difficulty: 'beginner',
        orderIndex: 74
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'What is the size of int data type in Java?',
        options: ['16 bits', '32 bits', '64 bits', 'Platform dependent'],
        correctAnswer: 1,
        explanation: 'int in Java is always 32 bits (4 bytes) regardless of platform.',
        difficulty: 'beginner',
        orderIndex: 75
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'Which access modifier makes a member accessible only within the same package?',
        options: ['private', 'protected', 'public', 'default (package-private)'],
        correctAnswer: 3,
        explanation: 'No access modifier (default/package-private) makes members accessible only within the same package.',
        difficulty: 'intermediate',
        orderIndex: 76
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'What is autoboxing in Java?',
        options: ['Automatic garbage collection', 'Automatic conversion from primitive to wrapper', 'Automatic method calls', 'Automatic imports'],
        correctAnswer: 1,
        explanation: 'Autoboxing is the automatic conversion between primitive types and their wrapper classes.',
        difficulty: 'intermediate',
        orderIndex: 77
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'Which statement is true about Java arrays?',
        options: ['Arrays are objects', 'Array size can change', 'Arrays can hold different data types', 'Arrays are primitive types'],
        correctAnswer: 0,
        explanation: 'In Java, arrays are objects that extend the Object class.',
        difficulty: 'intermediate',
        orderIndex: 78
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'What does the final keyword do when applied to a variable?',
        options: ['Makes it global', 'Makes it constant', 'Makes it private', 'Makes it static'],
        correctAnswer: 1,
        explanation: 'The final keyword makes a variable constant - its value cannot be changed once assigned.',
        difficulty: 'beginner',
        orderIndex: 79
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'What is the difference between == and .equals()?',
        options: ['No difference', '== compares references, .equals() compares content', '== is faster', '.equals() is deprecated'],
        correctAnswer: 1,
        explanation: '== compares object references, while .equals() compares the actual content/value.',
        difficulty: 'intermediate',
        orderIndex: 80
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'Which loop is best for iterating over collections?',
        options: ['for loop', 'while loop', 'do-while loop', 'enhanced for loop'],
        correctAnswer: 3,
        explanation: 'Enhanced for loop (for-each) is the most convenient for iterating over collections.',
        difficulty: 'beginner',
        orderIndex: 81
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'What is a checked exception?',
        options: ['Exception caught by compiler', 'Exception that must be handled or declared', 'Exception in main method', 'Exception in static blocks'],
        correctAnswer: 1,
        explanation: 'Checked exceptions must be either handled with try-catch or declared in method signature.',
        difficulty: 'intermediate',
        orderIndex: 82
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'What does the static keyword mean?',
        options: ['Cannot change', 'Belongs to class, not instance', 'Private access', 'Final value'],
        correctAnswer: 1,
        explanation: 'Static members belong to the class itself rather than any specific instance.',
        difficulty: 'intermediate',
        orderIndex: 83
      },
      {
        language: 'java',
        concept: 'basics',
        question: 'Which is correct about String in Java?',
        options: ['Strings are mutable', 'Strings are immutable', 'Strings are primitive', 'Strings are interfaces'],
        correctAnswer: 1,
        explanation: 'Strings in Java are immutable - once created, their value cannot be changed.',
        difficulty: 'intermediate',
        orderIndex: 84
      },

      // Java OOP
      {
        language: 'java',
        concept: 'oop',
        question: 'Which keyword is used to create a class in Java?',
        options: ['function', 'class', 'object', 'method'],
        correctAnswer: 1,
        explanation: 'The "class" keyword is used to create a class in Java.',
        difficulty: 'beginner',
        orderIndex: 85
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is encapsulation?',
        options: ['Hiding implementation details', 'Creating multiple objects', 'Inheriting from parent', 'Overriding methods'],
        correctAnswer: 0,
        explanation: 'Encapsulation is the principle of hiding internal implementation details and exposing only necessary interface.',
        difficulty: 'beginner',
        orderIndex: 86
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'Which keyword is used for inheritance?',
        options: ['inherits', 'extends', 'implements', 'super'],
        correctAnswer: 1,
        explanation: 'The "extends" keyword is used to establish inheritance between classes.',
        difficulty: 'beginner',
        orderIndex: 87
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is method overloading?',
        options: ['Redefining parent methods', 'Multiple methods with same name but different parameters', 'Making methods static', 'Adding more methods'],
        correctAnswer: 1,
        explanation: 'Method overloading allows multiple methods with the same name but different parameter lists.',
        difficulty: 'intermediate',
        orderIndex: 88
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is the super keyword used for?',
        options: ['Create objects', 'Access parent class members', 'Make methods public', 'Define constructors'],
        correctAnswer: 1,
        explanation: 'The super keyword is used to access parent class constructors, methods, and variables.',
        difficulty: 'intermediate',
        orderIndex: 89
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is an abstract class?',
        options: ['Class with no methods', 'Class that cannot be instantiated', 'Class with private methods', 'Class with static methods'],
        correctAnswer: 1,
        explanation: 'An abstract class cannot be instantiated directly and may contain abstract methods.',
        difficulty: 'intermediate',
        orderIndex: 90
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is an interface?',
        options: ['A class with methods', 'A contract defining method signatures', 'A type of inheritance', 'A package structure'],
        correctAnswer: 1,
        explanation: 'An interface is a contract that defines method signatures that implementing classes must provide.',
        difficulty: 'intermediate',
        orderIndex: 91
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is polymorphism?',
        options: ['Multiple inheritance', 'Same interface, different implementations', 'Private methods', 'Static binding'],
        correctAnswer: 1,
        explanation: 'Polymorphism allows objects of different types to be treated through the same interface.',
        difficulty: 'intermediate',
        orderIndex: 92
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is method overriding?',
        options: ['Creating new methods', 'Redefining parent class methods in child class', 'Making methods private', 'Adding parameters'],
        correctAnswer: 1,
        explanation: 'Method overriding allows a child class to provide a specific implementation of a parent class method.',
        difficulty: 'intermediate',
        orderIndex: 93
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is the difference between abstract class and interface?',
        options: ['No difference', 'Abstract class can have concrete methods, interface cannot', 'Interface can have variables, abstract class cannot', 'Abstract class is faster'],
        correctAnswer: 1,
        explanation: 'Abstract classes can contain concrete methods and variables, while traditional interfaces only had abstract methods.',
        difficulty: 'advanced',
        orderIndex: 94
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is composition?',
        options: ['Type of inheritance', 'Object containing other objects', 'Method combination', 'Variable combination'],
        correctAnswer: 1,
        explanation: 'Composition is a design principle where a class contains objects of other classes as members.',
        difficulty: 'advanced',
        orderIndex: 95
      },
      {
        language: 'java',
        concept: 'oop',
        question: 'What is the difference between composition and inheritance?',
        options: ['No difference', 'Composition is "has-a", inheritance is "is-a"', 'Composition is faster', 'Inheritance is deprecated'],
        correctAnswer: 1,
        explanation: 'Composition represents "has-a" relationships, while inheritance represents "is-a" relationships.',
        difficulty: 'advanced',
        orderIndex: 96
      },

      // Java Data Structures  
      {
        language: 'java',
        concept: 'data_structures',
        question: 'Which interface represents an ordered collection that allows duplicates?',
        options: ['Set', 'List', 'Map', 'Queue'],
        correctAnswer: 1,
        explanation: 'List interface represents an ordered collection that allows duplicate elements.',
        difficulty: 'beginner',
        orderIndex: 97
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'Which data structure uses LIFO (Last In, First Out)?',
        options: ['Queue', 'Stack', 'List', 'Set'],
        correctAnswer: 1,
        explanation: 'Stack follows LIFO principle where the last element added is the first one removed.',
        difficulty: 'beginner',
        orderIndex: 98
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'What is the time complexity of accessing an element by index in ArrayList?',
        options: ['O(1)', 'O(log n)', 'O(n)', 'O(n²)'],
        correctAnswer: 0,
        explanation: 'ArrayList provides constant time O(1) access to elements by index due to its underlying array structure.',
        difficulty: 'intermediate',
        orderIndex: 99
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'Which Map implementation maintains insertion order?',
        options: ['HashMap', 'TreeMap', 'LinkedHashMap', 'ConcurrentHashMap'],
        correctAnswer: 2,
        explanation: 'LinkedHashMap maintains the insertion order of key-value pairs.',
        difficulty: 'intermediate',
        orderIndex: 100
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'What is the difference between HashSet and TreeSet?',
        options: ['No difference', 'HashSet is unsorted, TreeSet is sorted', 'HashSet allows duplicates', 'TreeSet is faster'],
        correctAnswer: 1,
        explanation: 'HashSet provides unordered storage, while TreeSet maintains elements in sorted order.',
        difficulty: 'intermediate',
        orderIndex: 101
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'Which collection is best for frequent insertions and deletions at arbitrary positions?',
        options: ['ArrayList', 'LinkedList', 'Vector', 'Stack'],
        correctAnswer: 1,
        explanation: 'LinkedList is more efficient for insertions and deletions at arbitrary positions.',
        difficulty: 'intermediate',
        orderIndex: 102
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'What does the Comparable interface provide?',
        options: ['Object comparison logic', 'Natural ordering', 'Both A and B', 'Collection sorting'],
        correctAnswer: 2,
        explanation: 'Comparable interface provides natural ordering by defining how objects of a class are compared.',
        difficulty: 'intermediate',
        orderIndex: 103
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'What is the difference between Iterator and ListIterator?',
        options: ['No difference', 'ListIterator can traverse backwards', 'Iterator is faster', 'ListIterator is deprecated'],
        correctAnswer: 1,
        explanation: 'ListIterator extends Iterator and can traverse in both directions, also allows modifications.',
        difficulty: 'advanced',
        orderIndex: 104
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'Which data structure should you use for a phone book application?',
        options: ['ArrayList', 'LinkedList', 'HashMap', 'TreeSet'],
        correctAnswer: 2,
        explanation: 'HashMap is ideal for phone book as it provides fast key-value lookups by name.',
        difficulty: 'intermediate',
        orderIndex: 105
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'What is the load factor in HashMap?',
        options: ['Maximum size', 'Number of elements', 'Threshold for resizing', 'Hash function quality'],
        correctAnswer: 2,
        explanation: 'Load factor determines when HashMap should resize its internal array to maintain performance.',
        difficulty: 'advanced',
        orderIndex: 106
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'Which collection allows null values?',
        options: ['TreeSet', 'TreeMap keys', 'HashMap', 'PriorityQueue'],
        correctAnswer: 2,
        explanation: 'HashMap allows one null key and multiple null values, while TreeSet and TreeMap don\'t allow nulls.',
        difficulty: 'advanced',
        orderIndex: 107
      },
      {
        language: 'java',
        concept: 'data_structures',
        question: 'What is the difference between fail-fast and fail-safe iterators?',
        options: ['Speed difference', 'Fail-fast throws exception on concurrent modification', 'No difference', 'Fail-safe is deprecated'],
        correctAnswer: 1,
        explanation: 'Fail-fast iterators throw ConcurrentModificationException when collection is modified during iteration.',
        difficulty: 'advanced',
        orderIndex: 108
      },

      // Java Concurrency
      {
        language: 'java',
        concept: 'concurrency',
        question: 'Which interface should a class implement to be used with threads?',
        options: ['Thread', 'Runnable', 'Callable', 'Executor'],
        correctAnswer: 1,
        explanation: 'Implementing Runnable interface is preferred as Java supports single inheritance.',
        difficulty: 'beginner',
        orderIndex: 109
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What does the synchronized keyword do?',
        options: ['Makes method faster', 'Ensures thread-safe access', 'Makes method static', 'Prevents inheritance'],
        correctAnswer: 1,
        explanation: 'synchronized ensures that only one thread can access the synchronized block or method at a time.',
        difficulty: 'beginner',
        orderIndex: 110
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is a deadlock?',
        options: ['Thread termination', 'Two threads waiting for each other indefinitely', 'Memory leak', 'Exception type'],
        correctAnswer: 1,
        explanation: 'Deadlock occurs when two or more threads are blocked forever, waiting for each other.',
        difficulty: 'intermediate',
        orderIndex: 111
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is the purpose of Thread.join()?',
        options: ['Start thread', 'Wait for thread to complete', 'Kill thread', 'Create thread'],
        correctAnswer: 1,
        explanation: 'join() makes the calling thread wait until the specified thread completes execution.',
        difficulty: 'intermediate',
        orderIndex: 112
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'Which class provides thread-safe collections?',
        options: ['Collections', 'Thread', 'Concurrent', 'java.util.concurrent'],
        correctAnswer: 3,
        explanation: 'java.util.concurrent package provides thread-safe collection implementations.',
        difficulty: 'intermediate',
        orderIndex: 113
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is volatile keyword used for?',
        options: ['Memory management', 'Ensuring variable visibility across threads', 'Exception handling', 'Performance optimization'],
        correctAnswer: 1,
        explanation: 'volatile ensures that changes to a variable are visible to all threads immediately.',
        difficulty: 'intermediate',
        orderIndex: 114
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is the difference between wait() and sleep()?',
        options: ['No difference', 'wait() releases lock, sleep() doesn\'t', 'sleep() is faster', 'wait() is deprecated'],
        correctAnswer: 1,
        explanation: 'wait() releases the object\'s monitor lock, while sleep() keeps the lock.',
        difficulty: 'advanced',
        orderIndex: 115
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is ExecutorService?',
        options: ['Thread class', 'High-level thread management API', 'Database service', 'Web service'],
        correctAnswer: 1,
        explanation: 'ExecutorService provides a higher-level API for managing and controlling thread execution.',
        difficulty: 'intermediate',
        orderIndex: 116
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is a thread pool?',
        options: ['Collection of threads', 'Reusable threads for task execution', 'Thread storage', 'Thread synchronization'],
        correctAnswer: 1,
        explanation: 'Thread pool maintains a collection of reusable threads to execute tasks efficiently.',
        difficulty: 'intermediate',
        orderIndex: 117
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What does Future interface represent?',
        options: ['Past results', 'Result of asynchronous computation', 'Thread state', 'Time management'],
        correctAnswer: 1,
        explanation: 'Future represents the result of an asynchronous computation that may not be available yet.',
        difficulty: 'advanced',
        orderIndex: 118
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is the difference between synchronized and ReentrantLock?',
        options: ['No difference', 'ReentrantLock provides more flexibility', 'synchronized is faster', 'ReentrantLock is deprecated'],
        correctAnswer: 1,
        explanation: 'ReentrantLock provides more flexibility like try-lock, timed locking, and interruptible locking.',
        difficulty: 'advanced',
        orderIndex: 119
      },
      {
        language: 'java',
        concept: 'concurrency',
        question: 'What is atomic operation?',
        options: ['Very fast operation', 'Indivisible operation', 'Database operation', 'Math operation'],
        correctAnswer: 1,
        explanation: 'Atomic operation completes in a single step relative to other threads - it cannot be interrupted.',
        difficulty: 'advanced',
        orderIndex: 120
      },

      // Java Frameworks
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is Spring Framework primarily used for?',
        options: ['Desktop applications', 'Enterprise application development', 'Mobile development', 'Game development'],
        correctAnswer: 1,
        explanation: 'Spring Framework is primarily designed for enterprise Java application development.',
        difficulty: 'beginner',
        orderIndex: 121
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is Dependency Injection?',
        options: ['Code injection attack', 'Providing dependencies to objects externally', 'Database injection', 'Method injection'],
        correctAnswer: 1,
        explanation: 'Dependency Injection is a design pattern where dependencies are provided to objects rather than created by them.',
        difficulty: 'intermediate',
        orderIndex: 122
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'Which annotation is used to mark a class as a Spring component?',
        options: ['@Bean', '@Component', '@Service', 'All of the above'],
        correctAnswer: 3,
        explanation: '@Component, @Service, @Repository, and @Controller are all stereotype annotations for Spring components.',
        difficulty: 'intermediate',
        orderIndex: 123
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is Spring Boot?',
        options: ['Spring replacement', 'Auto-configuration framework built on Spring', 'Database framework', 'Testing framework'],
        correctAnswer: 1,
        explanation: 'Spring Boot provides auto-configuration and embedded servers to simplify Spring application development.',
        difficulty: 'beginner',
        orderIndex: 124
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is the purpose of @Autowired annotation?',
        options: ['Mark as component', 'Automatic dependency injection', 'Configuration property', 'Exception handling'],
        correctAnswer: 1,
        explanation: '@Autowired enables automatic dependency injection by Spring container.',
        difficulty: 'intermediate',
        orderIndex: 125
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is Spring MVC?',
        options: ['Database framework', 'Web application framework', 'Testing framework', 'Security framework'],
        correctAnswer: 1,
        explanation: 'Spring MVC is a web application framework based on Model-View-Controller pattern.',
        difficulty: 'intermediate',
        orderIndex: 126
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'Which annotation is used for REST endpoints?',
        options: ['@Controller', '@RestController', '@Service', '@Component'],
        correctAnswer: 1,
        explanation: '@RestController combines @Controller and @ResponseBody for RESTful web services.',
        difficulty: 'intermediate',
        orderIndex: 127
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is Hibernate?',
        options: ['Web framework', 'ORM (Object-Relational Mapping) framework', 'Testing framework', 'Security framework'],
        correctAnswer: 1,
        explanation: 'Hibernate is an ORM framework that maps Java objects to database tables.',
        difficulty: 'beginner',
        orderIndex: 128
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is JPA?',
        options: ['Java Persistence API specification', 'Java Package API', 'Java Protocol API', 'Java Performance API'],
        correctAnswer: 0,
        explanation: 'JPA is a specification for accessing, persisting, and managing data between Java objects and relational databases.',
        difficulty: 'intermediate',
        orderIndex: 129
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is the difference between Spring and Spring Boot?',
        options: ['No difference', 'Spring Boot provides auto-configuration', 'Spring Boot is faster', 'Spring is deprecated'],
        correctAnswer: 1,
        explanation: 'Spring Boot builds on Spring and provides auto-configuration, embedded servers, and production-ready features.',
        difficulty: 'intermediate',
        orderIndex: 130
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is ApplicationContext in Spring?',
        options: ['Application configuration', 'IoC container', 'Database context', 'Web context'],
        correctAnswer: 1,
        explanation: 'ApplicationContext is Spring\'s IoC container that manages bean lifecycle and dependencies.',
        difficulty: 'advanced',
        orderIndex: 131
      },
      {
        language: 'java',
        concept: 'frameworks',
        question: 'What is AOP (Aspect-Oriented Programming)?',
        options: ['Object programming', 'Cross-cutting concerns separation', 'Array programming', 'Asynchronous programming'],
        correctAnswer: 1,
        explanation: 'AOP allows separation of cross-cutting concerns like logging, security, and transactions.',
        difficulty: 'advanced',
        orderIndex: 132
      }
    ];

    const aiQuestions: InsertQuizQuestion[] = [
      // AI Fundamentals
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'Which of the following is NOT a type of machine learning?',
        options: ['Supervised Learning', 'Unsupervised Learning', 'Reinforcement Learning', 'Deterministic Learning'],
        correctAnswer: 3,
        explanation: 'Deterministic Learning is not a recognized type of machine learning. The main types are supervised, unsupervised, and reinforcement learning.',
        difficulty: 'intermediate',
        orderIndex: 133
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is the Turing Test designed to evaluate?',
        options: ['Computer speed', 'Machine intelligence', 'Algorithm efficiency', 'Data processing'],
        correctAnswer: 1,
        explanation: 'The Turing Test evaluates a machine\'s ability to exhibit intelligent behavior indistinguishable from a human.',
        difficulty: 'beginner',
        orderIndex: 134
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is the difference between Narrow AI and General AI?',
        options: ['Speed difference', 'Narrow AI focuses on specific tasks, General AI has human-level intelligence', 'Cost difference', 'Programming language'],
        correctAnswer: 1,
        explanation: 'Narrow AI is designed for specific tasks, while General AI would have human-level intelligence across all domains.',
        difficulty: 'beginner',
        orderIndex: 135
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is an algorithm in AI context?',
        options: ['A programming language', 'A step-by-step procedure for solving problems', 'A type of computer', 'A data structure'],
        correctAnswer: 1,
        explanation: 'An algorithm is a set of rules or instructions for solving a problem or performing a task.',
        difficulty: 'beginner',
        orderIndex: 136
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is the goal of Artificial General Intelligence (AGI)?',
        options: ['Faster computers', 'Human-level intelligence across all domains', 'Better graphics', 'Cheaper processing'],
        correctAnswer: 1,
        explanation: 'AGI aims to create machines with human-level intelligence that can understand and perform any intellectual task.',
        difficulty: 'intermediate',
        orderIndex: 137
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is expert system in AI?',
        options: ['A human expert', 'Computer system that emulates decision-making of human expert', 'Advanced calculator', 'Database system'],
        correctAnswer: 1,
        explanation: 'Expert systems are computer programs that emulate the decision-making ability of human experts in specific domains.',
        difficulty: 'intermediate',
        orderIndex: 138
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is the Chinese Room argument about?',
        options: ['Translation software', 'Whether machines can truly understand', 'Room design', 'Chinese philosophy'],
        correctAnswer: 1,
        explanation: 'The Chinese Room argument questions whether a machine can truly understand or just simulate understanding.',
        difficulty: 'advanced',
        orderIndex: 139
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is knowledge representation in AI?',
        options: ['Storing data', 'Ways to represent knowledge for AI systems', 'Memory management', 'File formats'],
        correctAnswer: 1,
        explanation: 'Knowledge representation involves methods for storing and organizing knowledge so AI systems can use it.',
        difficulty: 'intermediate',
        orderIndex: 140
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is the frame problem in AI?',
        options: ['Hardware frames', 'Difficulty in representing what changes and what doesn\'t', 'Picture frames', 'Framework selection'],
        correctAnswer: 1,
        explanation: 'The frame problem is the challenge of representing what aspects of the world change when an action is performed.',
        difficulty: 'advanced',
        orderIndex: 141
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is symbolic AI?',
        options: ['Using symbols as graphics', 'AI based on symbol manipulation and logic', 'Mathematical symbols', 'Programming symbols'],
        correctAnswer: 1,
        explanation: 'Symbolic AI uses symbols and rules to represent knowledge and perform reasoning.',
        difficulty: 'intermediate',
        orderIndex: 142
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is the difference between AI and Machine Learning?',
        options: ['No difference', 'AI is broader field, ML is a subset', 'ML is older', 'AI is only for robots'],
        correctAnswer: 1,
        explanation: 'AI is the broader field of making machines intelligent, while ML is a specific approach within AI.',
        difficulty: 'beginner',
        orderIndex: 143
      },
      {
        language: 'ai',
        concept: 'fundamentals',
        question: 'What is computational intelligence?',
        options: ['Computer speed', 'AI methods inspired by natural intelligence', 'Quantum computing', 'Parallel processing'],
        correctAnswer: 1,
        explanation: 'Computational intelligence refers to AI methods inspired by natural intelligence like neural networks and evolutionary algorithms.',
        difficulty: 'advanced',
        orderIndex: 144
      },

      // Machine Learning
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is the primary goal of supervised learning in machine learning?',
        options: ['To find patterns in unlabeled data', 'To learn from labeled training data to make predictions', 'To reduce the dimensionality of data', 'To optimize neural network architectures'],
        correctAnswer: 1,
        explanation: 'Supervised learning uses labeled training data to learn patterns and make predictions on new, unseen data.',
        difficulty: 'beginner',
        orderIndex: 145
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is the difference between classification and regression?',
        options: ['No difference', 'Classification predicts categories, regression predicts continuous values', 'Classification is faster', 'Regression is more accurate'],
        correctAnswer: 1,
        explanation: 'Classification predicts discrete categories/labels, while regression predicts continuous numerical values.',
        difficulty: 'beginner',
        orderIndex: 146
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is overfitting?',
        options: ['Model fits training data too well, performs poorly on new data', 'Model is too simple', 'Too much data', 'Training too fast'],
        correctAnswer: 0,
        explanation: 'Overfitting occurs when a model learns the training data too specifically and fails to generalize to new data.',
        difficulty: 'intermediate',
        orderIndex: 147
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is cross-validation used for?',
        options: ['Data cleaning', 'Model evaluation and selection', 'Feature engineering', 'Data visualization'],
        correctAnswer: 1,
        explanation: 'Cross-validation is used to evaluate how well a model will perform on unseen data by training and testing on different data splits.',
        difficulty: 'intermediate',
        orderIndex: 148
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is feature engineering?',
        options: ['Building models', 'Selecting and transforming input variables', 'Training algorithms', 'Testing models'],
        correctAnswer: 1,
        explanation: 'Feature engineering involves selecting, modifying, or creating input variables to improve model performance.',
        difficulty: 'intermediate',
        orderIndex: 149
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is the bias-variance tradeoff?',
        options: ['Speed vs accuracy', 'Simplicity vs complexity leading to different types of errors', 'Cost vs performance', 'Training vs testing'],
        correctAnswer: 1,
        explanation: 'Bias-variance tradeoff balances underfitting (high bias) and overfitting (high variance) to minimize total error.',
        difficulty: 'advanced',
        orderIndex: 150
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is ensemble learning?',
        options: ['Single model approach', 'Combining multiple models for better performance', 'Fast learning', 'Deep learning'],
        correctAnswer: 1,
        explanation: 'Ensemble learning combines predictions from multiple models to achieve better performance than any individual model.',
        difficulty: 'intermediate',
        orderIndex: 151
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is gradient descent?',
        options: ['Data preprocessing', 'Optimization algorithm to minimize cost function', 'Feature selection', 'Model evaluation'],
        correctAnswer: 1,
        explanation: 'Gradient descent is an optimization algorithm used to find the minimum of a cost function by iteratively moving toward the steepest descent.',
        difficulty: 'intermediate',
        orderIndex: 152
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is regularization?',
        options: ['Making data regular', 'Technique to prevent overfitting', 'Data normalization', 'Model training'],
        correctAnswer: 1,
        explanation: 'Regularization adds a penalty term to the cost function to prevent overfitting by discouraging complex models.',
        difficulty: 'intermediate',
        orderIndex: 153
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is unsupervised learning?',
        options: ['Learning without supervision', 'Finding patterns in data without labeled examples', 'Automated learning', 'Self-learning'],
        correctAnswer: 1,
        explanation: 'Unsupervised learning finds patterns and structures in data without labeled training examples.',
        difficulty: 'beginner',
        orderIndex: 154
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is clustering?',
        options: ['Grouping similar data points together', 'Predicting categories', 'Reducing dimensions', 'Cleaning data'],
        correctAnswer: 0,
        explanation: 'Clustering is an unsupervised learning technique that groups similar data points together.',
        difficulty: 'beginner',
        orderIndex: 155
      },
      {
        language: 'ai',
        concept: 'machine_learning',
        question: 'What is the curse of dimensionality?',
        options: ['Too many features making algorithms less effective', 'Mathematical complexity', 'Storage problems', 'Visualization issues'],
        correctAnswer: 0,
        explanation: 'The curse of dimensionality refers to problems that arise when working with high-dimensional data, making many algorithms less effective.',
        difficulty: 'advanced',
        orderIndex: 156
      },

      // Deep Learning
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is a neural network?',
        options: ['Network of computers', 'Computing system inspired by biological neural networks', 'Internet connection', 'Database network'],
        correctAnswer: 1,
        explanation: 'A neural network is a computing system inspired by biological neural networks, consisting of interconnected nodes (neurons).',
        difficulty: 'beginner',
        orderIndex: 157
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What makes deep learning "deep"?',
        options: ['Complex algorithms', 'Multiple hidden layers', 'Large datasets', 'Advanced mathematics'],
        correctAnswer: 1,
        explanation: 'Deep learning uses neural networks with multiple hidden layers (typically 3 or more) to learn complex patterns.',
        difficulty: 'beginner',
        orderIndex: 158
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is backpropagation?',
        options: ['Forward data flow', 'Algorithm for training neural networks by propagating errors backward', 'Data preprocessing', 'Model evaluation'],
        correctAnswer: 1,
        explanation: 'Backpropagation is an algorithm for training neural networks that calculates gradients by propagating errors backward through the network.',
        difficulty: 'intermediate',
        orderIndex: 159
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is a Convolutional Neural Network (CNN) best used for?',
        options: ['Text processing', 'Image recognition and computer vision', 'Time series prediction', 'Speech recognition'],
        correctAnswer: 1,
        explanation: 'CNNs are specifically designed for image recognition and computer vision tasks due to their ability to detect spatial patterns.',
        difficulty: 'intermediate',
        orderIndex: 160
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is a Recurrent Neural Network (RNN) good for?',
        options: ['Image classification', 'Sequential data like text and time series', 'Static data processing', 'Image generation'],
        correctAnswer: 1,
        explanation: 'RNNs are designed for sequential data where the order matters, such as text, speech, and time series.',
        difficulty: 'intermediate',
        orderIndex: 161
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is an activation function?',
        options: ['Function that activates the network', 'Function that introduces non-linearity to neurons', 'Data loading function', 'Model saving function'],
        correctAnswer: 1,
        explanation: 'Activation functions introduce non-linearity to neural networks, allowing them to learn complex patterns.',
        difficulty: 'intermediate',
        orderIndex: 162
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is dropout in neural networks?',
        options: ['Removing neurons permanently', 'Regularization technique that randomly ignores neurons during training', 'Network failure', 'Data loss'],
        correctAnswer: 1,
        explanation: 'Dropout is a regularization technique that randomly sets some neurons to zero during training to prevent overfitting.',
        difficulty: 'intermediate',
        orderIndex: 163
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is transfer learning?',
        options: ['Transferring data', 'Using pre-trained models for new but related tasks', 'Moving models between computers', 'Converting model formats'],
        correctAnswer: 1,
        explanation: 'Transfer learning uses knowledge from pre-trained models on similar tasks to improve performance on new tasks.',
        difficulty: 'intermediate',
        orderIndex: 164
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is a Generative Adversarial Network (GAN)?',
        options: ['Two neural networks competing against each other', 'Single network for generation', 'Classification network', 'Optimization algorithm'],
        correctAnswer: 0,
        explanation: 'GANs consist of two neural networks (generator and discriminator) that compete against each other to generate realistic data.',
        difficulty: 'advanced',
        orderIndex: 165
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is the vanishing gradient problem?',
        options: ['Gradients become too large', 'Gradients become too small in deep networks', 'Gradients disappear completely', 'Gradients become negative'],
        correctAnswer: 1,
        explanation: 'The vanishing gradient problem occurs when gradients become exponentially small as they propagate backward through deep networks.',
        difficulty: 'advanced',
        orderIndex: 166
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What are transformers in deep learning?',
        options: ['Data transformation tools', 'Attention-based neural network architecture', 'Image processing models', 'Optimization algorithms'],
        correctAnswer: 1,
        explanation: 'Transformers are neural network architectures that use attention mechanisms and have revolutionized natural language processing.',
        difficulty: 'advanced',
        orderIndex: 167
      },
      {
        language: 'ai',
        concept: 'deep_learning',
        question: 'What is batch normalization?',
        options: ['Normalizing input data', 'Technique to normalize inputs of each layer', 'Data preprocessing step', 'Model optimization'],
        correctAnswer: 1,
        explanation: 'Batch normalization normalizes the inputs to each layer, helping with training stability and speed.',
        difficulty: 'advanced',
        orderIndex: 168
      },

      // Natural Language Processing
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is tokenization in NLP?',
        options: ['Creating tokens for authentication', 'Breaking text into words or subwords', 'Encrypting text', 'Compressing text'],
        correctAnswer: 1,
        explanation: 'Tokenization is the process of breaking down text into individual words, phrases, or other meaningful units called tokens.',
        difficulty: 'beginner',
        orderIndex: 169
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What are stop words?',
        options: ['Words that stop processing', 'Common words like "the", "is", "at"', 'Final words in sentences', 'Words that cause errors'],
        correctAnswer: 1,
        explanation: 'Stop words are common words that are often filtered out during text processing because they carry little meaning.',
        difficulty: 'beginner',
        orderIndex: 170
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is stemming?',
        options: ['Finding word origins', 'Reducing words to their root form', 'Creating word trees', 'Analyzing sentence structure'],
        correctAnswer: 1,
        explanation: 'Stemming reduces words to their root or stem form by removing prefixes and suffixes.',
        difficulty: 'beginner',
        orderIndex: 171
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is the difference between stemming and lemmatization?',
        options: ['No difference', 'Lemmatization considers word context and returns actual words', 'Stemming is more accurate', 'Lemmatization is faster'],
        correctAnswer: 1,
        explanation: 'Lemmatization considers the context and returns actual dictionary words, while stemming just removes affixes.',
        difficulty: 'intermediate',
        orderIndex: 172
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is sentiment analysis?',
        options: ['Analyzing sentence structure', 'Determining emotional tone of text', 'Counting words', 'Translating languages'],
        correctAnswer: 1,
        explanation: 'Sentiment analysis determines the emotional tone or attitude expressed in text (positive, negative, neutral).',
        difficulty: 'beginner',
        orderIndex: 173
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is named entity recognition (NER)?',
        options: ['Recognizing famous people', 'Identifying and classifying entities like names, locations, organizations', 'Finding repeated words', 'Detecting errors'],
        correctAnswer: 1,
        explanation: 'NER identifies and classifies named entities in text such as person names, locations, organizations, etc.',
        difficulty: 'intermediate',
        orderIndex: 174
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is TF-IDF?',
        options: ['Translation framework', 'Term frequency-inverse document frequency weighting scheme', 'Text formatting', 'Document indexing'],
        correctAnswer: 1,
        explanation: 'TF-IDF measures the importance of a word in a document relative to a collection of documents.',
        difficulty: 'intermediate',
        orderIndex: 175
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is word embedding?',
        options: ['Inserting words into documents', 'Dense vector representations of words', 'Word encryption', 'Text formatting'],
        correctAnswer: 1,
        explanation: 'Word embeddings represent words as dense vectors that capture semantic relationships between words.',
        difficulty: 'intermediate',
        orderIndex: 176
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is the attention mechanism in NLP?',
        options: ['Focusing on important parts of input', 'User attention tracking', 'Error detection', 'Speed optimization'],
        correctAnswer: 0,
        explanation: 'Attention mechanisms allow models to focus on different parts of the input when making predictions.',
        difficulty: 'advanced',
        orderIndex: 177
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is BERT?',
        options: ['Basic text processor', 'Bidirectional encoder representations from transformers', 'Binary text format', 'Book reading tool'],
        correctAnswer: 1,
        explanation: 'BERT is a transformer-based model that learns bidirectional representations of text for various NLP tasks.',
        difficulty: 'advanced',
        orderIndex: 178
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is machine translation?',
        options: ['Converting machine code', 'Automatically translating text from one language to another', 'Moving machines', 'Code compilation'],
        correctAnswer: 1,
        explanation: 'Machine translation automatically translates text or speech from one natural language to another.',
        difficulty: 'beginner',
        orderIndex: 179
      },
      {
        language: 'ai',
        concept: 'nlp',
        question: 'What is the bag-of-words model?',
        options: ['Model for shopping', 'Text representation ignoring word order', 'Word storage system', 'Grammar model'],
        correctAnswer: 1,
        explanation: 'Bag-of-words represents text as an unordered collection of words, disregarding grammar and word order.',
        difficulty: 'intermediate',
        orderIndex: 180
      },

      // Computer Vision
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is computer vision?',
        options: ['Computer display technology', 'Field of AI that enables computers to interpret visual information', 'Virtual reality', 'Computer graphics'],
        correctAnswer: 1,
        explanation: 'Computer vision is a field of AI that trains computers to interpret and understand visual information from images and videos.',
        difficulty: 'beginner',
        orderIndex: 181
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is image classification?',
        options: ['Organizing image files', 'Assigning labels or categories to images', 'Compressing images', 'Editing images'],
        correctAnswer: 1,
        explanation: 'Image classification involves assigning predefined labels or categories to entire images based on their content.',
        difficulty: 'beginner',
        orderIndex: 182
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is object detection?',
        options: ['Finding objects in storage', 'Identifying and locating objects within images', 'Counting objects', 'Creating objects'],
        correctAnswer: 1,
        explanation: 'Object detection identifies what objects are present in an image and where they are located (usually with bounding boxes).',
        difficulty: 'intermediate',
        orderIndex: 183
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is the difference between object detection and image segmentation?',
        options: ['No difference', 'Detection uses boxes, segmentation identifies pixel-level boundaries', 'Detection is faster', 'Segmentation is obsolete'],
        correctAnswer: 1,
        explanation: 'Object detection typically uses bounding boxes, while segmentation identifies the precise pixel-level boundaries of objects.',
        difficulty: 'intermediate',
        orderIndex: 184
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is a convolution in the context of image processing?',
        options: ['Image rotation', 'Mathematical operation that applies a filter to extract features', 'Image compression', 'Color adjustment'],
        correctAnswer: 1,
        explanation: 'Convolution applies a filter (kernel) across an image to extract features like edges, textures, and patterns.',
        difficulty: 'intermediate',
        orderIndex: 185
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is edge detection?',
        options: ['Finding image borders', 'Identifying boundaries where pixel intensity changes rapidly', 'Cutting image edges', 'Image cropping'],
        correctAnswer: 1,
        explanation: 'Edge detection identifies boundaries in images where there are sharp changes in brightness or color.',
        difficulty: 'beginner',
        orderIndex: 186
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is facial recognition?',
        options: ['Recognizing face shapes', 'Identifying or verifying people from facial features', 'Face editing', 'Emotion detection'],
        correctAnswer: 1,
        explanation: 'Facial recognition identifies or verifies individuals by analyzing and comparing facial features.',
        difficulty: 'beginner',
        orderIndex: 187
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is optical character recognition (OCR)?',
        options: ['Character animation', 'Converting images of text into editable text', 'Character design', 'Text formatting'],
        correctAnswer: 1,
        explanation: 'OCR technology converts images of text (from scans, photos, etc.) into machine-readable text.',
        difficulty: 'intermediate',
        orderIndex: 188
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is image augmentation?',
        options: ['Making images larger', 'Artificially creating variations of training images', 'Improving image quality', 'Adding objects to images'],
        correctAnswer: 1,
        explanation: 'Image augmentation creates variations of training images through transformations like rotation, scaling, and flipping.',
        difficulty: 'intermediate',
        orderIndex: 189
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is feature extraction in computer vision?',
        options: ['Removing features', 'Identifying distinctive characteristics from images', 'Adding features', 'Feature counting'],
        correctAnswer: 1,
        explanation: 'Feature extraction identifies and extracts distinctive characteristics or patterns from images for analysis.',
        difficulty: 'intermediate',
        orderIndex: 190
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is YOLO in object detection?',
        options: ['You Only Live Once', 'You Only Look Once - real-time object detection algorithm', 'Yellow Object Location', 'Yet Another Learning Option'],
        correctAnswer: 1,
        explanation: 'YOLO (You Only Look Once) is a popular real-time object detection algorithm that processes images in a single forward pass.',
        difficulty: 'advanced',
        orderIndex: 191
      },
      {
        language: 'ai',
        concept: 'computer_vision',
        question: 'What is the purpose of pooling layers in CNNs?',
        options: ['Collecting data', 'Reducing spatial dimensions while retaining important information', 'Adding more features', 'Color processing'],
        correctAnswer: 1,
        explanation: 'Pooling layers reduce the spatial dimensions of feature maps while preserving the most important information.',
        difficulty: 'advanced',
        orderIndex: 192
      }
    ];

    // Add quiz questions
    [...pythonQuestions, ...javaQuestions, ...aiQuestions].forEach(question => {
      const id = randomUUID();
      this.quizQuestions.set(id, { 
        ...question, 
        id, 
        explanation: question.explanation || null,
        difficulty: question.difficulty || 'beginner',
        createdAt: new Date() 
      });
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      fullName: insertUser.fullName || null,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  // Tutorial methods
  async getTutorialsByLanguage(language: string): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values())
      .filter(tutorial => tutorial.language === language)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getTutorial(id: string): Promise<Tutorial | undefined> {
    return this.tutorials.get(id);
  }

  async createTutorial(tutorial: InsertTutorial): Promise<Tutorial> {
    const id = randomUUID();
    const newTutorial: Tutorial = { 
      ...tutorial, 
      id, 
      description: tutorial.description || null,
      codeExamples: tutorial.codeExamples || [],
      createdAt: new Date() 
    };
    this.tutorials.set(id, newTutorial);
    return newTutorial;
  }

  // Quiz methods
  async getQuizQuestionsByLanguage(language: string): Promise<QuizQuestion[]> {
    return Array.from(this.quizQuestions.values())
      .filter(question => question.language === language)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getQuizQuestionsByLanguageAndConcept(language: string, concept: string): Promise<QuizQuestion[]> {
    return Array.from(this.quizQuestions.values())
      .filter(question => question.language === language && question.concept === concept)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getQuizQuestion(id: string): Promise<QuizQuestion | undefined> {
    return this.quizQuestions.get(id);
  }

  async createQuizQuestion(question: InsertQuizQuestion): Promise<QuizQuestion> {
    const id = randomUUID();
    const newQuestion: QuizQuestion = { 
      ...question, 
      id, 
      explanation: question.explanation || null,
      difficulty: question.difficulty || 'beginner',
      createdAt: new Date() 
    };
    this.quizQuestions.set(id, newQuestion);
    return newQuestion;
  }

  // Quiz attempts
  async createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const id = randomUUID();
    const newAttempt: QuizAttempt = { ...attempt, id, completedAt: new Date() };
    this.quizAttempts.set(id, newAttempt);
    return newAttempt;
  }

  async getUserQuizAttempts(userId: string, language?: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values())
      .filter(attempt => attempt.userId === userId && (!language || attempt.language === language))
      .sort((a, b) => (b.completedAt?.getTime() || 0) - (a.completedAt?.getTime() || 0));
  }

  // User progress
  async getUserProgress(userId: string, language?: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values())
      .filter(progress => progress.userId === userId && (!language || progress.language === language));
  }

  async updateUserProgress(progressData: InsertUserProgress): Promise<UserProgress> {
    // Find existing progress or create new
    const existing = Array.from(this.userProgress.values())
      .find(p => p.userId === progressData.userId && 
                 p.language === progressData.language && 
                 p.tutorialId === progressData.tutorialId);

    if (existing) {
      const updated = { ...existing, ...progressData, lastAccessed: new Date() };
      this.userProgress.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const newProgress: UserProgress = { 
        ...progressData, 
        id, 
        tutorialId: progressData.tutorialId || null,
        completed: progressData.completed || false,
        lastAccessed: new Date() 
      };
      this.userProgress.set(id, newProgress);
      return newProgress;
    }
  }

  // Chat sessions
  async getChatSession(userId: string): Promise<ChatSession | undefined> {
    return Array.from(this.chatSessions.values())
      .find(session => session.userId === userId);
  }

  async createChatSession(session: InsertChatSession): Promise<ChatSession> {
    const id = randomUUID();
    const now = new Date();
    const newSession: ChatSession = { ...session, id, createdAt: now, updatedAt: now };
    this.chatSessions.set(id, newSession);
    return newSession;
  }

  async updateChatSession(id: string, messages: any[]): Promise<ChatSession | undefined> {
    const session = this.chatSessions.get(id);
    if (session) {
      const updated = { ...session, messages, updatedAt: new Date() };
      this.chatSessions.set(id, updated);
      return updated;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
