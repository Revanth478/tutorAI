import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertQuizAttemptSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "mzOuSWluCRxgL4LYg1wpJd78a0Gw8Z4M3nZ81/WWTnw=";

if (process.env.NODE_ENV === "production" && !process.env.JWT_SECRET) {
  throw new Error("JWT_SECRET environment variable is required for production. Please set it before starting the server.");
}


// Extend Request type to include user
interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    username: string;
    email: string;
  };
}

// Middleware to verify JWT tokens
function authenticateToken(req: AuthenticatedRequest, res: Response, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401);
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ error: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, username: user.username, email: user.email },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, fullName: user.fullName }
      });
    } catch (error) {
      console.error("Signup error:", error);
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.post("/api/auth/signin", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }

      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Verify password
      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, username: user.username, email: user.email },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({
        token,
        user: { id: user.id, username: user.username, email: user.email, fullName: user.fullName }
      });
    } catch (error) {
      console.error("Signin error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  // Tutorial routes
  app.get("/api/tutorials/:language", async (req, res) => {
    try {
      const { language } = req.params;
      const tutorials = await storage.getTutorialsByLanguage(language);
      res.json(tutorials);
    } catch (error) {
      console.error("Error fetching tutorials:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.get("/api/tutorial/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const tutorial = await storage.getTutorial(id);
      if (!tutorial) {
        return res.status(404).json({ error: "Tutorial not found" });
      }
      res.json(tutorial);
    } catch (error) {
      console.error("Error fetching tutorial:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  // Quiz routes
  app.get("/api/quiz/:language", async (req, res) => {
    try {
      const { language } = req.params;
      const questions = await storage.getQuizQuestionsByLanguage(language);
      // Remove correct answers from response for security
      const questionsWithoutAnswers = questions.map(q => ({
        ...q,
        correctAnswer: undefined
      }));
      res.json(questionsWithoutAnswers);
    } catch (error) {
      console.error("Error fetching quiz questions:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  // Concept-based quiz route
  app.get("/api/quiz/:language/:concept", async (req, res) => {
    try {
      const { language, concept } = req.params;
      const questions = await storage.getQuizQuestionsByLanguageAndConcept(language, concept);
      // Remove correct answers from response for security
      const questionsWithoutAnswers = questions.map(q => ({
        ...q,
        correctAnswer: undefined
      }));
      res.json(questionsWithoutAnswers);
    } catch (error) {
      console.error("Error fetching concept quiz questions:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/quiz/submit", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { language, concept, answers } = req.body;
      const userId = req.user!.userId;

      if (!language || !answers || !Array.isArray(answers)) {
        return res.status(400).json({ error: "Invalid quiz submission" });
      }

      // Get correct answers - use concept-specific if provided, otherwise language-based
      const questions = concept 
        ? await storage.getQuizQuestionsByLanguageAndConcept(language, concept)
        : await storage.getQuizQuestionsByLanguage(language);
      
      // Calculate score
      let score = 0;
      const results = answers.map((userAnswer, index) => {
        const question = questions[index];
        const isCorrect = question && userAnswer === question.correctAnswer;
        if (isCorrect) score++;
        
        return {
          questionId: question?.id,
          userAnswer,
          correctAnswer: question?.correctAnswer,
          isCorrect,
          explanation: question?.explanation
        };
      });

      // Save quiz attempt
      const attempt = await storage.createQuizAttempt({
        userId,
        language,
        concept: concept || 'general', // Default to 'general' for backwards compatibility
        score,
        totalQuestions: questions.length,
        answers: results
      });

      res.json({
        attemptId: attempt.id,
        score,
        totalQuestions: questions.length,
        percentage: Math.round((score / questions.length) * 100),
        results
      });
    } catch (error) {
      console.error("Error submitting quiz:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  // User progress routes
  app.get("/api/progress", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userId = req.user!.userId;
      const { language } = req.query;
      
      const progress = await storage.getUserProgress(userId, language as string);
      const quizAttempts = await storage.getUserQuizAttempts(userId, language as string);
      
      res.json({
        progress,
        quizAttempts
      });
    } catch (error) {
      console.error("Error fetching user progress:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/progress", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userId = req.user!.userId;
      const { language, tutorialId, completed } = req.body;

      const progress = await storage.updateUserProgress({
        userId,
        language,
        tutorialId,
        completed
      });

      res.json(progress);
    } catch (error) {
      console.error("Error updating progress:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  // Chat routes
  app.get("/api/chat", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userId = req.user!.userId;
      const session = await storage.getChatSession(userId);
      
      if (!session) {
        // Create new session with welcome message
        const newSession = await storage.createChatSession({
          userId,
          messages: [{
            role: 'assistant',
            content: "Hello! I'm your AI Tutor. I'm here to help you learn programming languages, understand concepts, and answer any questions you might have. How can I assist you today?",
            timestamp: new Date().toISOString()
          }]
        });
        return res.json(newSession);
      }
      
      res.json(session);
    } catch (error) {
      console.error("Error fetching chat session:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  app.post("/api/chat", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userId = req.user!.userId;
      const { message } = req.body;

      if (!message || !message.trim()) {
        return res.status(400).json({ error: "Message is required" });
      }

      // Get or create chat session
      let session = await storage.getChatSession(userId);
      if (!session) {
        session = await storage.createChatSession({
          userId,
          messages: []
        });
      }

      // Add user message
      const userMessage = {
        role: 'user',
        content: message.trim(),
        timestamp: new Date().toISOString()
      };

      // Simple AI response (in a real app, this would call an AI service)
      const aiResponse = {
        role: 'assistant',
        content: generateSimpleResponse(message),
        timestamp: new Date().toISOString()
      };

      const updatedMessages = [...(session.messages as any[]), userMessage, aiResponse];
      const updatedSession = await storage.updateChatSession(session.id, updatedMessages);

      res.json(updatedSession);
    } catch (error) {
      console.error("Error sending chat message:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Simple response generator (placeholder for real AI integration)
function generateSimpleResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('python')) {
    return "Great question about Python! Python is known for its simplicity and readability. What specific aspect of Python would you like to learn about? Variables, functions, data structures, or something else?";
  } else if (lowerMessage.includes('java')) {
    return "Java is a powerful object-oriented programming language! It's great for enterprise applications. Are you interested in learning about classes, inheritance, or maybe Java frameworks like Spring?";
  } else if (lowerMessage.includes('ai') || lowerMessage.includes('machine learning')) {
    return "Artificial Intelligence is a fascinating field! Are you interested in machine learning algorithms, neural networks, or maybe practical AI applications? I can help explain concepts from beginner to advanced level.";
  } else if (lowerMessage.includes('help') || lowerMessage.includes('learn')) {
    return "I'm here to help you learn! You can ask me about programming concepts, get explanations of code, or request tutorials on specific topics. What would you like to explore today?";
  } else {
    return "That's an interesting question! Can you provide more details so I can give you a more helpful response? I'm here to assist with programming concepts, tutorials, and coding questions.";
  }
}
