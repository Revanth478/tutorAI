import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Python from "@/pages/python";
import Java from "@/pages/java";
import AI from "@/pages/ai";
import QuizConcepts from "@/pages/quiz-concepts";
import ConceptQuiz from "@/pages/concept-quiz";
import Login from "@/pages/login";
import Chatbot from "@/pages/chatbot";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/python" component={Python} />
      <Route path="/java" component={Java} />
      <Route path="/ai" component={AI} />
      <Route path="/quiz/:language" component={QuizConcepts} />
      <Route path="/quiz/:language/:concept" component={ConceptQuiz} />
      <Route path="/login" component={Login} />
      <Route path="/chatbot" component={Chatbot} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
