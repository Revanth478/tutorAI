import { Link, useParams, useLocation } from "wouter";
import { ArrowLeft, ChevronRight, Trophy, Clock, Target } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const conceptInfo = {
  python: {
    title: "Python",
    color: "yellow",
    icon: "fab fa-python",
    concepts: [
      { id: "basics", name: "Python Basics", description: "Variables, syntax, and fundamental concepts", questions: 12 },
      { id: "datatypes", name: "Data Types", description: "Strings, numbers, booleans, and type conversion", questions: 12 },
      { id: "functions", name: "Functions", description: "Function definition, parameters, and return values", questions: 12 },
      { id: "modules", name: "Modules & Packages", description: "Importing, creating modules, and package management", questions: 12 },
      { id: "oop", name: "Object-Oriented Programming", description: "Classes, objects, inheritance, and polymorphism", questions: 12 },
      { id: "libraries", name: "Libraries & Frameworks", description: "Popular Python libraries and frameworks", questions: 12 }
    ]
  },
  java: {
    title: "Java",
    color: "red",
    icon: "fab fa-java", 
    concepts: [
      { id: "basics", name: "Java Fundamentals", description: "Syntax, variables, and basic programming concepts", questions: 12 },
      { id: "oop", name: "Object-Oriented Programming", description: "Classes, objects, inheritance, and polymorphism", questions: 12 },
      { id: "data_structures", name: "Data Structures", description: "Arrays, collections, lists, and maps", questions: 12 },
      { id: "concurrency", name: "Concurrency", description: "Threads, synchronization, and parallel programming", questions: 12 },
      { id: "frameworks", name: "Frameworks", description: "Spring, Hibernate, and enterprise development", questions: 12 }
    ]
  },
  ai: {
    title: "Artificial Intelligence",
    color: "purple",
    icon: "fas fa-brain",
    concepts: [
      { id: "fundamentals", name: "AI Fundamentals", description: "Introduction to artificial intelligence concepts", questions: 12 },
      { id: "machine_learning", name: "Machine Learning", description: "Supervised, unsupervised, and reinforcement learning", questions: 12 },
      { id: "deep_learning", name: "Deep Learning", description: "Neural networks, CNNs, and RNNs", questions: 12 },
      { id: "nlp", name: "Natural Language Processing", description: "Text processing, sentiment analysis, and language models", questions: 12 },
      { id: "computer_vision", name: "Computer Vision", description: "Image processing, object detection, and recognition", questions: 12 }
    ]
  }
};

const colorVariants = {
  yellow: {
    bg: "bg-gradient-to-br from-yellow-50 to-yellow-100",
    border: "border-yellow-200",
    text: "text-yellow-800",
    button: "bg-yellow-500 hover:bg-yellow-600",
    accent: "text-yellow-600"
  },
  red: {
    bg: "bg-gradient-to-br from-red-50 to-red-100", 
    border: "border-red-200",
    text: "text-red-800",
    button: "bg-red-500 hover:bg-red-600",
    accent: "text-red-600"
  },
  purple: {
    bg: "bg-gradient-to-br from-purple-50 to-purple-100",
    border: "border-purple-200", 
    text: "text-purple-800",
    button: "bg-purple-500 hover:bg-purple-600",
    accent: "text-purple-600"
  }
};

export default function QuizConcepts() {
  const { language } = useParams<{ language: string }>();
  const [, navigate] = useLocation();

  if (!language || !conceptInfo[language as keyof typeof conceptInfo]) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Language Not Found</h2>
          <Link href="/">
            <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Back to Home
            </button>
          </Link>
        </div>
      </div>
    );
  }

  const languageInfo = conceptInfo[language as keyof typeof conceptInfo];
  const colors = colorVariants[languageInfo.color as keyof typeof colorVariants];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-6xl mx-auto p-6">
        
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <button 
                data-testid="button-back-home"
                className="p-2 hover:bg-muted rounded-lg transition-colors"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
            </Link>
            <div className="flex items-center space-x-3">
              <div className={`w-12 h-12 ${colors.button} rounded-lg flex items-center justify-center`}>
                <i className={`${languageInfo.icon} text-white text-xl`}></i>
              </div>
              <div>
                <h1 className="text-3xl font-bold">{languageInfo.title} Quiz Concepts</h1>
                <p className="text-muted-foreground">Choose a concept to test your knowledge</p>
              </div>
            </div>
          </div>
        </header>

        {/* Concepts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {languageInfo.concepts.map((concept) => (
            <Link key={concept.id} href={`/quiz/${language}/${concept.id}`}>
              <div 
                data-testid={`concept-card-${concept.id}`}
                className={`${colors.bg} ${colors.border} border rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all duration-200 card-hover h-full`}
              >
                <div className="flex flex-col h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className={`text-xl font-bold ${colors.text} mb-2`}>{concept.name}</h3>
                      <p className={`text-sm ${colors.accent} mb-4`}>{concept.description}</p>
                    </div>
                    <ChevronRight className={`w-5 h-5 ${colors.accent} flex-shrink-0`} />
                  </div>
                  
                  <div className="mt-auto">
                    <div className="flex items-center justify-between text-sm mb-4">
                      <div className="flex items-center space-x-1">
                        <Target className={`w-4 h-4 ${colors.accent}`} />
                        <span className={colors.accent}>{concept.questions} Questions</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className={`w-4 h-4 ${colors.accent}`} />
                        <span className={colors.accent}>~{Math.ceil(concept.questions * 1.5)} min</span>
                      </div>
                    </div>
                    
                    <button 
                      data-testid={`button-start-${concept.id}`}
                      className={`w-full ${colors.button} text-white py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2`}
                    >
                      <Trophy className="w-4 h-4" />
                      <span>Start Quiz</span>
                    </button>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Statistics Footer */}
        <div className="mt-12 text-center">
          <div className={`${colors.bg} ${colors.border} border rounded-xl p-6`}>
            <h3 className={`text-2xl font-bold ${colors.text} mb-2`}>Ready to Master {languageInfo.title}?</h3>
            <p className={`${colors.accent} mb-4`}>
              Complete all {languageInfo.concepts.length} concepts • {languageInfo.concepts.reduce((sum, c) => sum + c.questions, 0)} total questions
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="text-center">
                <div className={`text-2xl font-bold ${colors.text}`}>{languageInfo.concepts.length}</div>
                <div className={`text-sm ${colors.accent}`}>Concepts</div>
              </div>
              <div className="text-center">
                <div className={`text-2xl font-bold ${colors.text}`}>{languageInfo.concepts.reduce((sum, c) => sum + c.questions, 0)}</div>
                <div className={`text-sm ${colors.accent}`}>Questions</div>
              </div>
              <div className="text-center">
                <div className={`text-2xl font-bold ${colors.text}`}>3</div>
                <div className={`text-sm ${colors.accent}`}>Difficulty Levels</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}