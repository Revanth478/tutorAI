import { Link } from "wouter";
import { ArrowLeft, Send, Mic, Paperclip, MoreVertical, Bot, User } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

export default function Chatbot() {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  // Fetch chat session
  const { data: chatSession, isLoading, refetch } = useQuery({
    queryKey: ['/api/chat'],
    enabled: isAuthenticated,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest('POST', '/api/chat', { message: messageText });
      return response.json();
    },
    onSuccess: () => {
      setMessage('');
      refetch(); // Refresh the chat session
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message",
        variant: "destructive",
      });
    },
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatSession]);

  const handleSendMessage = (e?: React.FormEvent) => {
    e?.preventDefault();
    
    if (!message.trim()) return;
    
    if (!isAuthenticated) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to chat with the AI tutor.",
        variant: "destructive",
      });
      return;
    }

    sendMessageMutation.mutate(message.trim());
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Bot className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Sign in to Chat</h2>
          <p className="text-muted-foreground mb-6">
            You need to be logged in to chat with the AI tutor.
          </p>
          <Link href="/login">
            <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Sign In
            </button>
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading chat...</p>
        </div>
      </div>
    );
  }

  const messages = chatSession?.messages || [];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <div className="max-w-4xl mx-auto w-full flex flex-col h-screen">
        
        {/* Header */}
        <header className="flex items-center justify-between p-6 border-b border-border bg-card">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <button 
                data-testid="button-back-home"
                className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back</span>
              </button>
            </Link>
            
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-semibold text-foreground">AI Tutor</h1>
                <p className="text-sm text-green-600 flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                  Online
                </p>
              </div>
            </div>
          </div>
          
          <button 
            data-testid="button-menu"
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </header>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((msg: any, index: number) => (
            <div key={index} className={`flex items-start space-x-3 ${
              msg.role === 'user' ? 'justify-end' : ''
            }`}>
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              
              <div className={`rounded-lg p-4 max-w-xs lg:max-w-md ${
                msg.role === 'user' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-card border border-border'
              }`}>
                <div className={`whitespace-pre-wrap ${
                  msg.role === 'user' ? 'text-primary-foreground' : 'text-foreground'
                }`}>
                  {msg.content}
                </div>
                <span className={`text-xs mt-2 block ${
                  msg.role === 'user' 
                    ? 'text-primary-foreground/70' 
                    : 'text-muted-foreground'
                }`}>
                  {msg.timestamp ? formatTime(msg.timestamp) : ''}
                </span>
              </div>

              {msg.role === 'user' && (
                <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-muted-foreground" />
                </div>
              )}
            </div>
          ))}
          
          {/* Loading indicator when sending message */}
          {sendMessageMutation.isPending && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-card border border-border rounded-lg p-4 max-w-xs lg:max-w-md">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:0.1s]"></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:0.2s]"></div>
                </div>
                <span className="text-xs text-muted-foreground mt-2 block">Typing...</span>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="border-t border-border p-6 bg-card">
          <form onSubmit={handleSendMessage} className="flex items-center space-x-3">
            <button 
              type="button"
              data-testid="button-attach"
              className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
            >
              <Paperclip className="w-5 h-5" />
            </button>
            
            <div className="flex-1 relative">
              <input
                data-testid="input-message"
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Ask me anything about programming..."
                className="w-full px-4 py-3 pr-12 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-background"
                disabled={sendMessageMutation.isPending}
              />
              <button 
                type="button"
                data-testid="button-voice"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground transition-colors"
              >
                <Mic className="w-4 h-4" />
              </button>
            </div>
            
            <button 
              type="submit"
              data-testid="button-send"
              disabled={sendMessageMutation.isPending || !message.trim()}
              className="bg-primary hover:bg-primary/90 disabled:opacity-50 text-primary-foreground p-3 rounded-lg transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          
          <div className="flex items-center justify-center mt-4 space-x-4">
            <Link href="/python">
              <button 
                data-testid="button-quick-python"
                className="px-4 py-2 bg-yellow-100 hover:bg-yellow-200 text-yellow-800 rounded-full text-sm transition-colors"
              >
                Python Help
              </button>
            </Link>
            <Link href="/java">
              <button 
                data-testid="button-quick-java"
                className="px-4 py-2 bg-red-100 hover:bg-red-200 text-red-800 rounded-full text-sm transition-colors"
              >
                Java Help
              </button>
            </Link>
            <Link href="/ai">
              <button 
                data-testid="button-quick-ai"
                className="px-4 py-2 bg-purple-100 hover:bg-purple-200 text-purple-800 rounded-full text-sm transition-colors"
              >
                AI Concepts
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
