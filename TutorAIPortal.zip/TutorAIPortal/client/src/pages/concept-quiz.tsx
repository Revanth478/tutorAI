import { Link, useParams, useLocation } from "wouter";
import { ArrowLeft, RotateCcw, Clock, CheckCircle, XCircle, Brain } from "lucide-react";
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

const conceptInfo = {
  python: {
    basics: "Python Basics",
    datatypes: "Data Types", 
    functions: "Functions",
    modules: "Modules & Packages",
    oop: "Object-Oriented Programming",
    libraries: "Libraries & Frameworks"
  },
  java: {
    basics: "Java Fundamentals",
    oop: "Object-Oriented Programming",
    data_structures: "Data Structures",
    concurrency: "Concurrency",
    frameworks: "Frameworks"
  },
  ai: {
    fundamentals: "AI Fundamentals",
    machine_learning: "Machine Learning",
    deep_learning: "Deep Learning",
    nlp: "Natural Language Processing",
    computer_vision: "Computer Vision"
  }
};

export default function ConceptQuiz() {
  const { language, concept } = useParams<{ language: string; concept: string }>();
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [quizResults, setQuizResults] = useState<any>(null);

  // Fetch quiz questions for specific concept
  const { data: questions, isLoading, error } = useQuery({
    queryKey: ['/api/quiz', language, concept],
    queryFn: async () => {
      const response = await apiRequest('GET', `/api/quiz/${language}/${concept}`);
      return response.json();
    },
    enabled: !!language && !!concept
  });

  // Submit quiz mutation
  const submitQuizMutation = useMutation({
    mutationFn: async (answers: number[]) => {
      const response = await apiRequest('POST', `/api/quiz/submit`, {
        language,
        concept,
        answers
      });
      return response.json();
    },
    onSuccess: (result) => {
      setQuizResults(result);
      setQuizCompleted(true);
      queryClient.invalidateQueries({ queryKey: ['/api/progress'] });
      
      toast({
        title: "Quiz Completed!",
        description: `You scored ${result.score}/${result.totalQuestions}`,
        variant: result.score >= result.totalQuestions * 0.7 ? "default" : "destructive",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit quiz",
        variant: "destructive",
      });
    },
  });

  // Timer effect
  useEffect(() => {
    if (!quizCompleted && questions?.length > 0) {
      const timer = setInterval(() => {
        setTimeElapsed(prev => prev + 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [quizCompleted, questions]);

  // Validation
  if (!language || !concept) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Invalid Quiz Parameters</h2>
          <Link href="/">
            <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Back to Home
            </button>
          </Link>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Brain className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Sign in to Take Quiz</h2>
          <p className="text-muted-foreground mb-6">
            You need to be logged in to take quizzes and track your progress.
          </p>
          <Link href="/login">
            <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Sign In
            </button>
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading quiz questions...</p>
        </div>
      </div>
    );
  }

  if (error || !questions || questions.length === 0) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <XCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">Quiz Not Available</h2>
          <p className="text-muted-foreground mb-6">
            This quiz concept is not available yet or an error occurred loading the questions.
          </p>
          <Link href={`/quiz/${language}`}>
            <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
              Back to {language.charAt(0).toUpperCase() + language.slice(1)} Quizzes
            </button>
          </Link>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const languageInfo = conceptInfo[language as keyof typeof conceptInfo];
  const conceptTitle = languageInfo ? (languageInfo as any)[concept] || concept : concept;

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestionIndex] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      // Submit quiz
      submitQuizMutation.mutate(selectedAnswers);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleRestartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswers([]);
    setTimeElapsed(0);
    setQuizCompleted(false);
    setQuizResults(null);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  if (quizCompleted && quizResults) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <div className="max-w-4xl mx-auto p-6">
          {/* Header */}
          <header className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Link href={`/quiz/${language}`}>
                <button 
                  data-testid="button-back-concepts"
                  className="p-2 hover:bg-muted rounded-lg transition-colors"
                >
                  <ArrowLeft className="w-6 h-6" />
                </button>
              </Link>
              <h1 className="text-3xl font-bold">Quiz Completed!</h1>
            </div>
          </header>

          {/* Results */}
          <div className="bg-card border border-border rounded-xl p-8 text-center mb-8">
            <div className="w-24 h-24 mx-auto mb-6">
              {quizResults.score >= quizResults.totalQuestions * 0.7 ? (
                <CheckCircle className="w-24 h-24 text-green-500" />
              ) : (
                <XCircle className="w-24 h-24 text-red-500" />
              )}
            </div>
            
            <h2 className="text-2xl font-bold mb-4">{conceptTitle}</h2>
            <div className="text-6xl font-bold mb-4">
              {quizResults.score}/{quizResults.totalQuestions}
            </div>
            <p className="text-xl text-muted-foreground mb-6">
              {Math.round((quizResults.score / quizResults.totalQuestions) * 100)}% Correct
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md mx-auto mb-8">
              <div className="bg-muted rounded-lg p-4">
                <div className="text-2xl font-bold">{formatTime(timeElapsed)}</div>
                <div className="text-sm text-muted-foreground">Time Taken</div>
              </div>
              <div className="bg-muted rounded-lg p-4">
                <div className="text-2xl font-bold">{questions.length}</div>
                <div className="text-sm text-muted-foreground">Questions</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href={`/quiz/${language}`}>
                <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors">
                  Back to Concepts
                </button>
              </Link>
              
              <button 
                data-testid="button-restart-quiz"
                onClick={handleRestartQuiz}
                className="bg-muted hover:bg-muted/80 text-foreground px-6 py-3 rounded-lg transition-colors flex items-center justify-center space-x-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Restart Quiz</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-4xl mx-auto p-6">
        
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link href={`/quiz/${language}`}>
              <button 
                data-testid="button-back-concepts"
                className="p-2 hover:bg-muted rounded-lg transition-colors"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold">{conceptTitle} Quiz</h1>
              <p className="text-muted-foreground">{language.charAt(0).toUpperCase() + language.slice(1)} • Question {currentQuestionIndex + 1} of {questions.length}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-muted px-4 py-2 rounded-lg">
              <Clock className="w-4 h-4" />
              <span data-testid="quiz-timer">{formatTime(timeElapsed)}</span>
            </div>
          </div>
        </header>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-muted-foreground">Progress</span>
            <span className="text-sm text-muted-foreground">{Math.round(((currentQuestionIndex + 1) / questions.length) * 100)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Question */}
        <div className="bg-card border border-border rounded-xl p-8 mb-8">
          <h2 className="text-xl font-bold mb-6" data-testid="question-text">
            {currentQuestion.question}
          </h2>
          
          <div className="space-y-4">
            {currentQuestion.options.map((option: string, index: number) => (
              <button
                key={index}
                data-testid={`option-${index}`}
                onClick={() => handleAnswerSelect(index)}
                className={`w-full p-4 text-left rounded-lg border transition-all duration-200 ${
                  selectedAnswers[currentQuestionIndex] === index
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border hover:border-primary/50 hover:bg-muted/50'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswers[currentQuestionIndex] === index
                      ? 'border-primary bg-primary'
                      : 'border-muted-foreground'
                  }`}>
                    {selectedAnswers[currentQuestionIndex] === index && (
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    )}
                  </div>
                  <span className="flex-1">{option}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <button
            data-testid="button-previous"
            onClick={handlePrevious}
            disabled={currentQuestionIndex === 0}
            className="px-6 py-3 text-muted-foreground hover:text-foreground disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Previous
          </button>
          
          <div className="flex space-x-2">
            {questions.map((_: any, index: number) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full ${
                  index === currentQuestionIndex
                    ? 'bg-primary'
                    : selectedAnswers[index] !== undefined
                    ? 'bg-green-500'
                    : 'bg-muted'
                }`}
              ></div>
            ))}
          </div>
          
          <button
            data-testid="button-next"
            onClick={handleNext}
            disabled={selectedAnswers[currentQuestionIndex] === undefined || submitQuizMutation.isPending}
            className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {submitQuizMutation.isPending 
              ? 'Submitting...' 
              : currentQuestionIndex === questions.length - 1 
                ? 'Finish Quiz' 
                : 'Next'
            }
          </button>
        </div>
      </div>
    </div>
  );
}