import { Link } from "wouter";
import { GraduationCap, Code, Brain, MessageCircle, Users, TrendingUp, Bot, UserCircle } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="w-full px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          {/* Logo Section */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <GraduationCap className="text-primary-foreground text-lg" />
            </div>
            <span className="text-xl font-bold text-primary">Tutor AI</span>
          </div>
          
          {/* Login/Signup Button */}
          <Link href="/login">
            <button 
              data-testid="button-login"
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2.5 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center space-x-2"
            >
              <UserCircle className="w-4 h-4" />
              <span>Login / Signup</span>
            </button>
          </Link>
        </div>
      </header>

      <main className="min-h-screen px-6 py-8">
        <div className="max-w-7xl mx-auto">
          
          {/* Main Title */}
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-4">
              Welcome to Tutor AI !!!
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Master programming languages with AI-powered personalized learning and interactive quizzes
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-16">
            
            {/* Quizzes Section */}
            <div className="lg:col-span-1">
              <div className="bg-card rounded-xl shadow-lg border border-border p-6 card-hover">
                <div className="flex items-center mb-6">
                  <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center mr-3">
                    <i className="fas fa-question-circle text-accent-foreground text-sm"></i>
                  </div>
                  <h2 className="text-2xl font-bold text-card-foreground">Quizzes</h2>
                </div>
                
                <div className="space-y-4">
                  {/* Python Quiz Button */}
                  <Link href="/quiz/python">
                    <button 
                      data-testid="button-quiz-python"
                      className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-yellow-900 py-4 px-6 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center justify-center space-x-3"
                    >
                      <i className="fab fa-python text-xl"></i>
                      <div className="text-left">
                        <div className="font-semibold">Python Quizzes</div>
                        <div className="text-xs opacity-80">6 concepts available</div>
                      </div>
                    </button>
                  </Link>
                  
                  {/* Java Quiz Button */}
                  <Link href="/quiz/java">
                    <button 
                      data-testid="button-quiz-java"
                      className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white py-4 px-6 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center justify-center space-x-3"
                    >
                      <i className="fab fa-java text-xl"></i>
                      <div className="text-left">
                        <div className="font-semibold">Java Quizzes</div>
                        <div className="text-xs opacity-80">5 concepts available</div>
                      </div>
                    </button>
                  </Link>
                  
                  {/* AI Quiz Button */}
                  <Link href="/quiz/ai">
                    <button 
                      data-testid="button-quiz-ai"
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-4 px-6 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center justify-center space-x-3"
                    >
                      <Brain className="text-xl" />
                      <div className="text-left">
                        <div className="font-semibold">AI Quizzes</div>
                        <div className="text-xs opacity-80">5 concepts available</div>
                      </div>
                    </button>
                  </Link>
                </div>
              </div>
            </div>

            {/* Languages Section */}
            <div className="lg:col-span-3">
              <div className="bg-card rounded-xl shadow-lg border border-border p-8">
                <div className="flex items-center mb-8">
                  <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center mr-4">
                    <Code className="text-primary-foreground" />
                  </div>
                  <h2 className="text-3xl font-bold text-card-foreground">Languages</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Python Card */}
                  <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-6 border border-yellow-200 card-hover">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i className="fab fa-python text-white text-2xl"></i>
                      </div>
                      <h3 className="text-xl font-bold text-yellow-800 mb-3">Python</h3>
                      <p className="text-yellow-700 mb-6 text-sm">Learn Python programming with interactive lessons and real-world projects</p>
                      <Link href="/python">
                        <button 
                          data-testid="button-learn-python"
                          className="w-full bg-yellow-500 hover:bg-yellow-600 text-white py-3 px-6 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md"
                        >
                          Start Learning
                        </button>
                      </Link>
                    </div>
                  </div>
                  
                  {/* Java Card */}
                  <div className="bg-gradient-to-br from-red-50 to-orange-100 rounded-xl p-6 border border-red-200 card-hover">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i className="fab fa-java text-white text-2xl"></i>
                      </div>
                      <h3 className="text-xl font-bold text-red-800 mb-3">Java</h3>
                      <p className="text-red-700 mb-6 text-sm">Master Java development with enterprise-grade tutorials and exercises</p>
                      <Link href="/java">
                        <button 
                          data-testid="button-learn-java"
                          className="w-full bg-red-500 hover:bg-red-600 text-white py-3 px-6 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md"
                        >
                          Start Learning
                        </button>
                      </Link>
                    </div>
                  </div>
                  
                  {/* AI Card */}
                  <div className="bg-gradient-to-br from-purple-50 to-pink-100 rounded-xl p-6 border border-purple-200 card-hover">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Brain className="text-white text-2xl" />
                      </div>
                      <h3 className="text-xl font-bold text-purple-800 mb-3">Artificial Intelligence</h3>
                      <p className="text-purple-700 mb-6 text-sm">Explore AI concepts, machine learning, and neural networks</p>
                      <Link href="/ai">
                        <button 
                          data-testid="button-learn-ai"
                          className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 px-6 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md"
                        >
                          Start Learning
                        </button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Features Section */}
          <div className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-foreground mb-4">Why Choose Tutor AI?</h2>
              <p className="text-muted-foreground text-lg max-w-3xl mx-auto">
                Experience personalized learning powered by artificial intelligence
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-6 bg-card rounded-xl border border-border card-hover">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Bot className="text-blue-600 text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">AI-Powered Learning</h3>
                <p className="text-muted-foreground">Adaptive curriculum that adjusts to your learning pace and style</p>
              </div>
              
              <div className="text-center p-6 bg-card rounded-xl border border-border card-hover">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="text-green-600 text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Progress Tracking</h3>
                <p className="text-muted-foreground">Monitor your learning journey with detailed analytics and insights</p>
              </div>
              
              <div className="text-center p-6 bg-card rounded-xl border border-border card-hover">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="text-purple-600 text-xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Community Support</h3>
                <p className="text-muted-foreground">Connect with learners worldwide and get help from expert tutors</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Chatbot Button */}
      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50">
        <Link href="/chatbot">
          <button 
            data-testid="button-chatbot"
            className="bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white px-8 py-4 rounded-full font-medium transition-all duration-200 shadow-lg hover:shadow-xl card-hover flex items-center space-x-3"
          >
            <MessageCircle className="text-xl" />
            <span className="text-lg">Chat with AI Tutor</span>
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
          </button>
        </Link>
      </div>

      {/* Footer */}
      <footer className="bg-muted mt-16 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex justify-center items-center space-x-3 mb-4">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <GraduationCap className="text-primary-foreground" />
            </div>
            <span className="text-lg font-bold text-primary">Tutor AI</span>
          </div>
          <p className="text-muted-foreground text-sm">
            © 2024 Tutor AI. Empowering learners with intelligent education technology.
          </p>
        </div>
      </footer>
    </div>
  );
}
