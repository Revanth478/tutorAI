import { Link } from "wouter";
import { ArrowLeft, Play, FileText, Code, CheckCircle } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function Python() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [expandedTutorial, setExpandedTutorial] = useState<string | null>(null);

  const { data: tutorials, isLoading } = useQuery({
    queryKey: ['/api/tutorials/python'],
  });

  // Fetch user progress
  const { data: progressData } = useQuery({
    queryKey: ['/api/progress?language=python'],
    enabled: isAuthenticated,
  });

  // Update progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async ({ tutorialId, completed }: { tutorialId: string; completed: boolean }) => {
      const response = await apiRequest('POST', '/api/progress', {
        language: 'python',
        tutorialId,
        completed,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/progress'] });
      toast({
        title: "Progress Updated",
        description: "Your tutorial progress has been saved.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update progress",
        variant: "destructive",
      });
    },
  });

  const getProgressForTutorial = (tutorialId: string) => {
    if (!progressData || !('progress' in progressData) || !Array.isArray(progressData.progress)) return null;
    return progressData.progress.find(
      (p: any) => p.tutorialId === tutorialId && p.language === 'python'
    );
  };

  const handleTutorialAction = (tutorial: any, action: 'view' | 'complete') => {
    if (!isAuthenticated) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to track your progress.",
        variant: "destructive",
      });
      return;
    }

    if (action === 'view') {
      setExpandedTutorial(expandedTutorial === tutorial.id ? null : tutorial.id);
      // Mark as accessed
      updateProgressMutation.mutate({ tutorialId: tutorial.id, completed: false });
    } else if (action === 'complete') {
      updateProgressMutation.mutate({ tutorialId: tutorial.id, completed: true });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading Python tutorials...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/">
            <button 
              data-testid="button-back-home"
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
          </Link>
        </div>

        {/* Title Section */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fab fa-python text-white text-3xl"></i>
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">Python Learning Path</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Master Python programming from basics to advanced concepts with our comprehensive curriculum
          </p>
        </div>

        {/* Learning Modules */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {tutorials && Array.isArray(tutorials) && tutorials.map((tutorial: any, index: number) => {
            const icons = [Play, Code, FileText];
            const colors = ['text-green-600', 'text-blue-600', 'text-purple-600'];
            const Icon = icons[index % icons.length];
            const iconColor = colors[index % colors.length];
            const progress = getProgressForTutorial(tutorial.id);
            const isCompleted = progress?.completed || false;
            const isExpanded = expandedTutorial === tutorial.id;
            
            return (
              <div key={tutorial.id} className="bg-card rounded-xl shadow-lg border border-border p-6 card-hover">
                <div className="flex items-center mb-4">
                  <Icon className={`w-6 h-6 ${iconColor} mr-3`} />
                  <h3 className="text-xl font-semibold">{tutorial.title}</h3>
                </div>
                <p className="text-muted-foreground mb-4">{tutorial.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Tutorial {tutorial.orderIndex}</span>
                  <div className="flex items-center space-x-2">
                    {progress?.lastAccessed && (
                      <span className="text-xs text-blue-600">Viewed</span>
                    )}
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-green-600" data-testid={`completed-${tutorial.id}`} />
                    ) : (
                      <div className="w-5 h-5 border-2 border-gray-300 rounded-full" data-testid={`incomplete-${tutorial.id}`}></div>
                    )}
                  </div>
                </div>
                
                {/* Tutorial Content Preview */}
                <div className="mt-4 pt-4 border-t border-border">
                  {isExpanded ? (
                    <div className="space-y-4">
                      <p className="text-sm text-foreground">
                        {tutorial.content}
                      </p>
                      <div className="flex space-x-2">
                        <button 
                          data-testid={`button-complete-${tutorial.id}`}
                          onClick={() => handleTutorialAction(tutorial, 'complete')}
                          disabled={updateProgressMutation.isPending || isCompleted}
                          className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                            isCompleted 
                              ? 'bg-green-100 text-green-700 cursor-not-allowed'
                              : 'bg-primary text-primary-foreground hover:bg-primary/90'
                          }`}
                        >
                          {isCompleted ? '✓ Completed' : 'Mark Complete'}
                        </button>
                        <button 
                          data-testid={`button-collapse-${tutorial.id}`}
                          onClick={() => setExpandedTutorial(null)}
                          className="px-4 py-2 text-sm border border-border rounded-lg hover:bg-muted transition-colors"
                        >
                          Collapse
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {tutorial.content}
                      </p>
                      <button 
                        data-testid={`button-read-more-${tutorial.id}`}
                        onClick={() => handleTutorialAction(tutorial, 'view')}
                        disabled={updateProgressMutation.isPending}
                        className="text-primary text-sm mt-2 hover:text-primary/80 transition-colors disabled:opacity-50"
                      >
                        {updateProgressMutation.isPending ? 'Loading...' : 'Read more →'}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link href="/quiz/python">
            <button 
              data-testid="button-python-quiz"
              className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-yellow-900 py-6 px-8 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center justify-center space-x-3"
            >
              <i className="fas fa-question-circle text-2xl"></i>
              <span className="text-lg">Take Python Quiz</span>
            </button>
          </Link>

          <Link href="/chatbot">
            <button 
              data-testid="button-python-tutor"
              className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white py-6 px-8 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center justify-center space-x-3"
            >
              <i className="fas fa-comments text-2xl"></i>
              <span className="text-lg">Chat with Python Tutor</span>
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
