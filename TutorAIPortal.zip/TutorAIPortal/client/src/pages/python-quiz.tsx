import { Link } from "wouter";
import { ArrowLeft, Clock, Trophy, RotateCcw } from "lucide-react";
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

export default function PythonQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [timeLeft, setTimeLeft] = useState(900); // 15 minutes in seconds

  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  // Fetch quiz questions
  const { data: questions, isLoading } = useQuery({
    queryKey: ['/api/quiz/python'],
  });

  // Submit quiz mutation
  const submitMutation = useMutation({
    mutationFn: async (quizAnswers: number[]) => {
      const response = await apiRequest('POST', '/api/quiz/submit', {
        language: 'python',
        answers: quizAnswers,
      });
      return response.json();
    },
    onSuccess: (result) => {
      setShowResults(true);
      // Invalidate progress cache after quiz completion
      queryClient.invalidateQueries({ queryKey: ['/api/progress'] });
      toast({
        title: "Quiz Completed!",
        description: `You scored ${result.score}/${result.totalQuestions} (${result.percentage}%)`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit quiz",
        variant: "destructive",
      });
    },
  });

  // Timer effect
  useEffect(() => {
    if (timeLeft > 0 && !showResults) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showResults) {
      handleSubmitQuiz();
    }
  }, [timeLeft, showResults]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer === null) {
      toast({
        title: "Please select an answer",
        description: "You must select an answer before continuing.",
        variant: "destructive",
      });
      return;
    }

    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedAnswer;
    setAnswers(newAnswers);
    setSelectedAnswer(null);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      handleSubmitQuiz(newAnswers);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedAnswer(answers[currentQuestion - 1] ?? null);
    }
  };

  const handleSubmitQuiz = (finalAnswers?: number[]) => {
    const quizAnswers = finalAnswers || answers;
    if (!isAuthenticated) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to submit the quiz.",
        variant: "destructive",
      });
      return;
    }
    submitMutation.mutate(quizAnswers);
  };

  const handleRestartQuiz = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setSelectedAnswer(null);
    setShowResults(false);
    setTimeLeft(900);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading quiz questions...</p>
        </div>
      </div>
    );
  }

  if (!questions || questions.length === 0) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">No quiz questions available.</p>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <button 
              data-testid="button-back-home"
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
          </Link>
          
          <div className="flex items-center space-x-4 text-muted-foreground">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span className={timeLeft < 300 ? 'text-red-500' : ''}>{formatTime(timeLeft)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Trophy className="w-4 h-4" />
              <span>{currentQuestion + 1}/{questions.length}</span>
            </div>
          </div>
        </div>

        {/* Title Section */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fab fa-python text-white text-2xl"></i>
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-4">Python Quiz</h1>
          <p className="text-lg text-muted-foreground">
            Test your Python knowledge with interactive questions
          </p>
        </div>

        {/* Quiz Content */}
        {!showResults ? (
          <div className="bg-card rounded-xl shadow-lg border border-border p-8 mb-8">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-medium text-muted-foreground">
                  Question {currentQuestion + 1} of {questions.length}
                </span>
                <div className="w-32 h-2 bg-muted rounded-full">
                  <div 
                    className="h-2 bg-primary rounded-full transition-all duration-300"
                    style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-6">
                {currentQ.question}
              </h2>
              
              <div className="space-y-4">
                {currentQ.options.map((option: string, index: number) => (
                  <button 
                    key={index}
                    data-testid={`option-${String.fromCharCode(65 + index).toLowerCase()}`}
                    onClick={() => handleAnswerSelect(index)}
                    className={`w-full text-left p-4 border rounded-lg transition-colors ${
                      selectedAnswer === index
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:bg-accent hover:border-accent'
                    }`}
                  >
                    <span className="font-medium text-accent mr-3">
                      {String.fromCharCode(65 + index)}.
                    </span>
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-between">
              <button 
                data-testid="button-previous"
                onClick={handlePreviousQuestion}
                className="px-6 py-2 border border-border rounded-lg hover:bg-muted transition-colors disabled:opacity-50"
                disabled={currentQuestion === 0}
              >
                Previous
              </button>
              
              <button 
                data-testid="button-next"
                onClick={handleNextQuestion}
                disabled={submitMutation.isPending}
                className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
              >
                {submitMutation.isPending ? 'Submitting...' : 
                 currentQuestion === questions.length - 1 ? 'Submit Quiz' : 'Next Question'}
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-card rounded-xl shadow-lg border border-border p-8 mb-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-4">Quiz Completed!</h2>
            <p className="text-muted-foreground text-lg">
              You've finished the Python quiz. Check your score above.
            </p>
          </div>
        )}

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link href="/python">
            <button 
              data-testid="button-python-lessons"
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-white py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
            >
              <i className="fab fa-python"></i>
              <span>Python Lessons</span>
            </button>
          </Link>
          
          <button 
            data-testid="button-restart-quiz"
            onClick={handleRestartQuiz}
            className="w-full bg-muted hover:bg-muted/80 text-foreground py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart Quiz</span>
          </button>
        </div>
      </div>
    </div>
  );
}
