import { Link } from "wouter";
import { ArrowLeft, Play, FileText, Code, CheckCircle, Brain } from "lucide-react";

export default function AI() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/">
            <button 
              data-testid="button-back-home"
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
          </Link>
        </div>

        {/* Title Section */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Brain className="text-white text-3xl" />
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">Artificial Intelligence Learning Path</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore AI concepts, machine learning algorithms, and neural networks with practical implementations
          </p>
        </div>

        {/* Learning Modules */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <div className="bg-card rounded-xl shadow-lg border border-border p-6 card-hover">
            <div className="flex items-center mb-4">
              <Play className="w-6 h-6 text-green-600 mr-3" />
              <h3 className="text-xl font-semibold">AI Fundamentals</h3>
            </div>
            <p className="text-muted-foreground mb-4">Introduction to artificial intelligence and its applications</p>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">7 lessons</span>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
          </div>

          <div className="bg-card rounded-xl shadow-lg border border-border p-6 card-hover">
            <div className="flex items-center mb-4">
              <Code className="w-6 h-6 text-blue-600 mr-3" />
              <h3 className="text-xl font-semibold">Machine Learning</h3>
            </div>
            <p className="text-muted-foreground mb-4">Supervised and unsupervised learning algorithms</p>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">14 lessons</span>
              <div className="w-5 h-5 border-2 border-gray-300 rounded-full"></div>
            </div>
          </div>

          <div className="bg-card rounded-xl shadow-lg border border-border p-6 card-hover">
            <div className="flex items-center mb-4">
              <FileText className="w-6 h-6 text-purple-600 mr-3" />
              <h3 className="text-xl font-semibold">Deep Learning</h3>
            </div>
            <p className="text-muted-foreground mb-4">Neural networks, CNNs, and RNNs with TensorFlow</p>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">18 lessons</span>
              <div className="w-5 h-5 border-2 border-gray-300 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link href="/quiz/ai">
            <button 
              data-testid="button-ai-quiz"
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-6 px-8 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center justify-center space-x-3"
            >
              <i className="fas fa-question-circle text-2xl"></i>
              <span className="text-lg">Take AI Quiz</span>
            </button>
          </Link>

          <Link href="/chatbot">
            <button 
              data-testid="button-ai-tutor"
              className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white py-6 px-8 rounded-lg font-medium transition-all duration-200 shadow-sm hover:shadow-md card-hover flex items-center justify-center space-x-3"
            >
              <i className="fas fa-comments text-2xl"></i>
              <span className="text-lg">Chat with AI Tutor</span>
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
