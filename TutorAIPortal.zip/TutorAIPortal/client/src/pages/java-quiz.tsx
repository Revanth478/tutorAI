import { Link } from "wouter";
import { ArrowLeft, Clock, Trophy, RotateCcw } from "lucide-react";

export default function JavaQuiz() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <button 
              data-testid="button-back-home"
              className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
          </Link>
          
          <div className="flex items-center space-x-4 text-muted-foreground">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span>15:00</span>
            </div>
            <div className="flex items-center space-x-2">
              <Trophy className="w-4 h-4" />
              <span>0/10</span>
            </div>
          </div>
        </div>

        {/* Title Section */}
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fab fa-java text-white text-2xl"></i>
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-4">Java Quiz</h1>
          <p className="text-lg text-muted-foreground">
            Test your Java knowledge with challenging questions
          </p>
        </div>

        {/* Quiz Content */}
        <div className="bg-card rounded-xl shadow-lg border border-border p-8 mb-8">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-muted-foreground">Question 1 of 10</span>
              <div className="w-32 h-2 bg-muted rounded-full">
                <div className="w-3 h-2 bg-red-500 rounded-full"></div>
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-6">
              Which keyword is used to create a class in Java?
            </h2>
            
            <div className="space-y-4">
              <button 
                data-testid="option-a"
                className="w-full text-left p-4 border border-border rounded-lg hover:bg-accent hover:border-accent transition-colors"
              >
                <span className="font-medium text-accent mr-3">A.</span>
                function
              </button>
              
              <button 
                data-testid="option-b"
                className="w-full text-left p-4 border border-border rounded-lg hover:bg-accent hover:border-accent transition-colors"
              >
                <span className="font-medium text-accent mr-3">B.</span>
                class
              </button>
              
              <button 
                data-testid="option-c"
                className="w-full text-left p-4 border border-border rounded-lg hover:bg-accent hover:border-accent transition-colors"
              >
                <span className="font-medium text-accent mr-3">C.</span>
                object
              </button>
              
              <button 
                data-testid="option-d"
                className="w-full text-left p-4 border border-border rounded-lg hover:bg-accent hover:border-accent transition-colors"
              >
                <span className="font-medium text-accent mr-3">D.</span>
                method
              </button>
            </div>
          </div>

          <div className="flex justify-between">
            <button 
              data-testid="button-previous"
              className="px-6 py-2 border border-border rounded-lg hover:bg-muted transition-colors disabled:opacity-50"
              disabled
            >
              Previous
            </button>
            
            <button 
              data-testid="button-next"
              className="px-6 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
            >
              Next Question
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link href="/java">
            <button 
              data-testid="button-java-lessons"
              className="w-full bg-red-500 hover:bg-red-600 text-white py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
            >
              <i className="fab fa-java"></i>
              <span>Java Lessons</span>
            </button>
          </Link>
          
          <button 
            data-testid="button-restart-quiz"
            className="w-full bg-muted hover:bg-muted/80 text-foreground py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart Quiz</span>
          </button>
        </div>
      </div>
    </div>
  );
}
